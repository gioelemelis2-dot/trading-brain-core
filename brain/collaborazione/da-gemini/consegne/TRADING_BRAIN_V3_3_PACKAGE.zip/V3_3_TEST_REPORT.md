# REPORT DEI TEST — TRADING BRAIN V3.3

**Autore:** Gemini Antigravity (Quantitative Research Lab)  
**Data di esecuzione:** 12 Novembre 2026  
**Ambiente:** Python 3.13 / Mac OS (pura libreria standard)  
**File di test:** `test_prop_risk_v3_3.py`  
**Esito globale:** **20 TEST ESEGUITI, 20 SUPERATI, 0 FALLITI, 0 ERRORI** (Tempo totale: 4.54s)

---

## 1. Dettaglio dei Risultati per Test Unitario

| # | Funzione di Test | Proprietà Verificata | Riserva / Mutante | Esito | Note / Valori Numerici |
| :--- | :--- | :--- | :--- | :--- | :--- |
| **01** | `test_p01_crn_coupling_invariance` | Accoppiamento deterministico CRN per-sfida | P-01 | **PASSED** | 2.500 sfide; 0 sfide passate solo con MAE |
| **02** | `test_p02_mae_generalization_multi_scenario` | Generalizzazione analitica per WR 0.5/RR 1 e WR 0.4/RR 2 | P-02 | **PASSED** | WR 0.5: $F(0.5) = 0.3333$; WR 0.4: $F(0.5) = 0.3981$ |
| **03** | `test_p05_barrier_priority_ordering` | Priorità barriere a chiusura: Rovina > Max Loss > Daily Loss | P-05 | **PASSED** | Violazione simultanea restituisce `max_loss` |
| **04** | `test_c01_markov_stationary_start` | Campionamento stazionario al trade 1 da $\pi$ | C-01 | **PASSED** | 25.000 simulazioni; $P(\text{Loss}) \approx 0.60$ |
| **05** | `test_c02_markov_admissibility` | Validazione vincolo stazionario Markov | C-02 | **PASSED** | $p_{LL} < 1 - WR/(1-WR)$ solleva `ValueError` |
| **06** | `test_c03_slippage_execution` | Esecuzione effettiva e impatto dello slippage | C-03 | **PASSED** | Pass rate con slippage inferiore a quello senza |
| **07** | `test_c12_unlimited_days_ftmo` | Regime a giorni illimitati (FTMO post-2023) | C-12 | **PASSED** | Zero timeout; pass rate $> 98\%$ a rischio $0.25\%$ |
| **08** | `test_q01_kelly_confidence_interval_at_95_and_68` | IC Kelly al 95% vs +-1 SE per N=300 trade reali | Q-01, V13-V15 | **PASSED** | IC 95%: $[-0.0163, +0.3163]$ (inferiore $<0$) |
| **09** | `test_q02_min_days_regression_freezes_risk` | Congelamento del rischio al target prima di min_days | Q-02.1, V12, V17 | **PASSED** | Raggiunto target a giorno 1; uscita a giorno 4 con $eq = 0.10$ |
| **10** | `test_q02_barrier_priority_during_trade_mae` | Priorità barriere intra-trade su MAE flottante | Q-02.2, V04, V08 | **PASSED** | Violazione simultanea $\to$ `max_loss`; singola $\to$ `daily_loss` |
| **11** | `test_q02_mae_through_engine_rr_diff_2` | MAE su RR 1 attraverso motore con pavimento 5% | Q-02.3 | **PASSED** | Frequenza daily loss $1/6 \approx 0.1667$ ($z = 0.13$) |
| **12** | `test_mae_profondo_attraverso_motore_rr1` | MAE profondo su RR 1 con pavimento 7.5% | S-02, V10, V03 | **PASSED** | Frequenza teorica esatta $1/14 \approx 0.0714$ ($z = 0.38$) |
| **13** | `test_fase2_esatta_e_prodotto_due_fasi` | Concordanza Fase 2 (0.8572) e prodotto intera sfida (0.6686) | S-01, S-02, V07 | **PASSED** | Fase 2: $z = 0.59 < 4$; Sfida intera: $z = 0.75 < 4$ |
| **14** | `test_q02_exact_concordance_group_a_multi_config` | Concordanza Gruppo A su 5 scenari eterogenei | Q-02.5 | **PASSED** | Tutti i 5 scenari entro $4\cdot SE$ (massimo $|z| \le 1.67$) |
| **15** | `test_wilson_valori_noti` | Quantili esatti NormalDist per livelli 90%, 95%, 99% | S-04, S-07, V21 | **PASSED** | 90%: $[0.4188, 0.5812]$, 95%: $[0.4038, 0.5962]$, 99%: $[0.3753, 0.6247]$ |
| **16** | `test_slippage_deterministico` | Formula Lomax per $u=0.5$ e rispetto cap $3.0R$ | S-07, V19, V20 | **PASSED** | $u=0.5 \implies 0.0234867R$; $u \to 1 \implies \text{cap } 3.0R$ |
| **17** | `test_momenti_slippage_forma_chiusa` | Media campionaria vs valore teorico esatto | S-07 | **PASSED** | Media 50k trade coincide con $0.060169R$ ($z = 0.45 < 3$) |
| **18** | `test_mae_soglia_mu_quasi_zero` | Campionamento MAE in prossimità della soglia $\mu = 2\cdot 10^{-7}$ | S-07, V22 | **PASSED** | Coincide con $F(d)$ teorica ($z = 0.18$) |
| **19** | `test_s05_mae_asymmetric_guards_extreme_values` | Guardie asimmetriche e calcolabilità di WR 0.99 / RR 500 | S-05 | **PASSED** | Precisione deriva $|P_{\text{win}} - 0.99| < 10^{-12}$; 8 quantili entro $4\cdot SE$ |
| **20** | `test_s06_comprehensive_input_validation` | Audit sistematico: rifiuto NaN, Inf, negativi, max < min days | S-06 | **PASSED** | Rifiuto perentorio con `ValueError` su tutti i casi anomali |

---

## 2. Analisi di Mutazione e Neutralizzazione dei Mutanti (V01–V22)

| Mutante | Descrizione della Mutazione | Test che lo Uccide in V3.3 | Esito |
| :--- | :--- | :--- | :--- |
| **V01** | Fase 2 riusa i generatori pseudocasuali della Fase 1 | Nessuno (quasi-equivalente statistico documentato) | **Sopravvive (documentato)** |
| **V02** | Drift browniano calcolato con formula errata | `test_p02_mae_generalization_multi_scenario` | **UCCISO** |
| **V03** | $RR$ hardcoded a $2.0$ nel motore | `test_mae_profondo_attraverso_motore_rr1` | **UCCISO** |
| **V04** | Inversione priorità barriere durante il trade (Daily prima di Max Loss) | `test_q02_barrier_priority_during_trade_mae` (Caso 1) | **UCCISO** |
| **V05** | Inversione priorità barriere a chiusura posizione | `test_p05_barrier_priority_ordering` | **UCCISO** |
| **V06** | Target lock ignorato: trade continuano anche dopo il target | `test_q02_min_days_regression_freezes_risk` | **UCCISO** |
| **V07** | Target Fase 2 mutato a target Fase 1 in `run_full_challenge` | `test_fase2_esatta_e_prodotto_due_fasi` (Passata sfida intera) | **UCCISO** |
| **V08** | Controllo Daily Loss durante il trade rimosso/ignorato | `test_q02_barrier_priority_during_trade_mae` (Caso 2) | **UCCISO** |
| **V09** | Slippage calcolato con scala errata | `test_slippage_deterministico` | **UCCISO** |
| **V10** | MAE troncato a $-0.50R$ | `test_mae_profondo_attraverso_motore_rr1` (Pavimento 7.5%) | **UCCISO** |
| **V11** | Deriva MAE $\mu$ impostata a 0 per tutti gli scenari | `test_p02_mae_generalization_multi_scenario` (WR 0.40) | **UCCISO** |
| **V12** | Regressione bug `min_days`: trade continuano nei giorni 2, 3, 4 | `test_q02_min_days_regression_freezes_risk` | **UCCISO** |
| **V13** | Quantile Kelly IC 95% impostato a $z=1.0$ (reintroduzione N-01) | `test_q01_kelly_confidence_interval_at_95_and_68` | **UCCISO** |
| **V14** | Errore standard Kelly calcolato senza fattore $(RR + 1)$ | `test_q01_kelly_confidence_interval_at_95_and_68` | **UCCISO** |
| **V15** | Costo $cost\_r$ ignorato nel calcolo di $E[R]$ | `test_q01_kelly_confidence_interval_at_95_and_68` | **UCCISO** |
| **V16** | Re-seeding per-sfida rimosso (reintroduzione P-01) | `test_p01_crn_coupling_invariance` | **UCCISO** |
| **V17** | `min_days` ignorato: uscita immediata al raggiungimento target | `test_q02_min_days_regression_freezes_risk` | **UCCISO** |
| **V18** | Re-inizializzazione Markov campiona da uniforme invece che da $\pi$ | `test_c01_markov_stationary_start` | **UCCISO** |
| **V19** | Esponente Lomax $-\alpha$ invece di $-1/\alpha$ | `test_slippage_deterministico` ($u=0.5$) | **UCCISO** |
| **V20** | Cap slippage $3.0R$ ignorato | `test_slippage_deterministico` ($u \to 1$) | **UCCISO** |
| **V21** | Quantile Wilson hardcoded a $z=1.0$ | `test_wilson_valori_noti` (Livelli 90%, 95%, 99%) | **UCCISO** |
| **V22** | Soglia $\mu \approx 0$ del campionatore impostata a $0.1$ | `test_mae_soglia_mu_quasi_zero` ($\mu = 2\cdot 10^{-7}$) | **UCCISO** |

**Sintesi Mutazionale:** 21 mutanti non-equivalenti su 21 uccisi determinatamente (**100% dei mutanti non-equivalenti neutralizzati**).
