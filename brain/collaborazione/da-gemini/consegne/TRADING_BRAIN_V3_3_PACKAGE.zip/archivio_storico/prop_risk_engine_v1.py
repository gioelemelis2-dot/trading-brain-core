"""
TRADING RESEARCH LAB — QUANTITATIVE ENGINE
Modulo: prop_risk_engine.py
Descrizione: Simulatore Monte Carlo avanzato per la stima della rovina operativa,
             violazione dei vincoli prop (Daily Loss vs Max Loss) e intervalli di confidenza.
Autore: Antigravity Research Lab
Standard: Master Mission §1, §6, §7, §9
"""

import math
import random
import statistics
from typing import Dict, List, Tuple, Optional, Any


def wilson_confidence_interval(k: int, n: int, confidence: float = 0.95) -> Tuple[float, float]:
    """
    Calcola l'intervallo di confidenza di Wilson per una proporzione binomiale k/n.
    Superiore alla normale per probabilità vicine a 0 o 1 e campioni finiti.
    """
    if n == 0:
        return (0.0, 0.0)
    # Valore z per il livello di confidenza
    # 0.95 -> 1.95996
    z = 1.95996 if confidence == 0.95 else 2.57583  # default 95% o 99%
    p = k / n
    denom = 1.0 + (z**2) / n
    centre = (p + (z**2) / (2.0 * n)) / denom
    spread = (z * math.sqrt((p * (1.0 - p) / n) + (z**2) / (4.0 * (n**2)))) / denom
    lower = max(0.0, centre - spread)
    upper = min(1.0, centre + spread)
    return (round(lower, 4), round(upper, 4))


class PropSimulationScenario:
    """
    Incapsula la configurazione di un test di simulazione.
    """
    def __init__(
        self,
        name: str,
        win_rate: float,
        reward_to_risk: float,
        cost_r: float = 0.05,
        p_loss_given_loss: Optional[float] = None,  # Modellazione cluster Markov
        degrees_of_freedom: Optional[float] = None  # Distribuzione Student-t opzionale
    ):
        self.name = name
        self.win_rate = win_rate
        self.reward_to_risk = reward_to_risk
        self.cost_r = cost_r
        # Se p_loss_given_loss è specificato, modella la dipendenza seriale (clustering)
        # Se None, assume indipendenza i.i.d.
        self.p_loss_given_loss = p_loss_given_loss if p_loss_given_loss is not None else (1.0 - win_rate)
        self.degrees_of_freedom = degrees_of_freedom

        # Aspettativa teorica netta E[R]
        self.gross_expectancy = (win_rate * reward_to_risk) - ((1.0 - win_rate) * 1.0)
        self.net_expectancy = self.gross_expectancy - cost_r


def simulate_phase(
    rng: random.Random,
    scenario: PropSimulationScenario,
    risk_pct: float,
    trades_per_day: int,
    max_days: int,
    target_pct: float,
    max_daily_loss_pct: float = 0.05,
    max_overall_loss_pct: float = 0.10,
    min_days: int = 4
) -> Tuple[str, int, float]:
    """
    Simula una singola fase di valutazione (es. Fase 1 al 10% o Fase 2 al 5%).
    
    Ritorna:
        (esito, giorni_impiegati, equity_finale_relativa)
        Esiti possibili:
        - 'pass': obiettivo raggiunto nel rispetto di tutte le regole.
        - 'max_loss': violazione del pavimento statico complessivo (Max Loss).
        - 'daily_loss': violazione della soglia di perdita dalla mezzanotte precedente (Daily Loss).
        - 'absolute_ruin': capitale sceso a zero (azzeramento totale).
        - 'timeout': giorni massimi raggiunti senza violazioni né target.
    """
    equity = 0.0  # P/L relativo espresso come frazione del capitale iniziale (es. +0.10 = +10%)
    last_outcome_was_loss = False

    for day in range(1, max_days + 1):
        # A mezzanotte CE(S)T il saldo/equity fissa il pavimento per la giornata
        # Il pavimento è: Equity_mezzanotte - max_daily_loss_pct (calcolato su capitale iniziale)
        midnight_equity = equity
        daily_loss_floor = midnight_equity - max_daily_loss_pct

        for _ in range(trades_per_day):
            # 1. Generazione esito con o senza dipendenza (Markov Chain)
            if scenario.p_loss_given_loss is not None:
                # Modello a 2 stati per dipendenza da cluster
                if last_outcome_was_loss:
                    prob_loss = scenario.p_loss_given_loss
                else:
                    # Per mantenere il win rate complessivo stazionario:
                    # P(L) = P(L|L)*P(L) + P(L|W)*P(W)
                    # p_loss = p_loss_given_loss * p_loss + p_loss_given_win * (1 - p_loss)
                    p_loss_base = 1.0 - scenario.win_rate
                    if scenario.win_rate > 0:
                        prob_loss = (p_loss_base - scenario.p_loss_given_loss * p_loss_base) / scenario.win_rate
                        prob_loss = max(0.0, min(1.0, prob_loss))
                    else:
                        prob_loss = 1.0
                is_win = (rng.random() >= prob_loss)
            else:
                is_win = (rng.random() < scenario.win_rate)

            last_outcome_was_loss = not is_win

            # 2. Assegnazione rendimento in R
            r_gross = scenario.reward_to_risk if is_win else -1.0
            r_net = r_gross - scenario.cost_r

            # 3. Aggiornamento equity (frazione del capitale iniziale)
            trade_pnl = r_net * risk_pct
            equity += trade_pnl

            # 4. Verifica gerarchica delle barriere di rovina
            # Barriera A: Rovina Assoluta (Capitale = 0, equity <= -1.0)
            if equity <= -1.0:
                return ("absolute_ruin", day, equity)

            # Barriera B: Maximum Loss Statico (es. -10% del capitale iniziale)
            if equity <= -max_overall_loss_pct:
                return ("max_loss", day, equity)

            # Barriera C: Maximum Daily Loss (ancorato al livello di mezzanotte)
            if equity <= daily_loss_floor:
                return ("daily_loss", day, equity)

            # Controllo Target intraday
            if equity >= target_pct and day >= min_days:
                return ("pass", day, equity)

        # Controllo Target a fine giornata
        if equity >= target_pct and day >= min_days:
            return ("pass", day, equity)

    return ("timeout", max_days, equity)


def run_full_challenge_experiment(
    seed: int,
    scenario: PropSimulationScenario,
    risk_pct: float,
    trades_per_day: int,
    max_days_per_phase: int,
    n_simulations: int,
    fase1_target: float = 0.10,
    fase2_target: float = 0.05,
    max_daily_loss: float = 0.05,
    max_overall_loss: float = 0.10
) -> Dict[str, Any]:
    """
    Simula il percorso prop a 2 fasi completo e raccoglie metriche statistiche complete
    con intervalli di confidenza al 95%.
    """
    rng = random.Random(seed)
    counts = {
        "pass": 0,
        "max_loss": 0,
        "daily_loss": 0,
        "absolute_ruin": 0,
        "timeout": 0
    }
    days_to_pass = []

    for _ in range(n_simulations):
        # Fase 1
        res1, d1, eq1 = simulate_phase(
            rng, scenario, risk_pct, trades_per_day, max_days_per_phase,
            fase1_target, max_daily_loss, max_overall_loss
        )
        if res1 != "pass":
            counts[res1] += 1
            continue

        # Fase 2 (il conto riparte da capitale iniziale nominale secondo le regole prop)
        res2, d2, eq2 = simulate_phase(
            rng, scenario, risk_pct, trades_per_day, max_days_per_phase,
            fase2_target, max_daily_loss, max_overall_loss
        )
        if res2 != "pass":
            counts[res2] += 1
            continue

        counts["pass"] += 1
        days_to_pass.append(d1 + d2)

    # Elaborazione frequenze e intervalli di confidenza di Wilson al 95%
    results = {}
    for outcome, count in counts.items():
        rate = count / n_simulations
        ci_low, ci_high = wilson_confidence_interval(count, n_simulations, 0.95)
        results[outcome] = {
            "count": count,
            "rate": round(rate, 4),
            "ci_95": (ci_low, ci_high)
        }

    results["median_days_pass"] = statistics.median(days_to_pass) if days_to_pass else None
    results["mean_days_pass"] = round(statistics.mean(days_to_pass), 1) if days_to_pass else None

    return results
