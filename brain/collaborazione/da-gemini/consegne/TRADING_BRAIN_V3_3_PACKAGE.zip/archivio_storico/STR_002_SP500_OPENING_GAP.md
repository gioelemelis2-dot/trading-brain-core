# STR-002 — S&P 500 Opening Gap Dynamics (Fade vs Continuation)
## Scheda di Ricerca Pre-Registrata (§5.2, §5.3 Master Mission)

**Identificativo:** STR-002  
**Nome Strategia:** S&P 500 Cash Session Opening Gap (Asimmetria Fade vs Continuation)  
**Famiglia:** Trading Intraday / Session Dynamics & Liquidity Imbalance  
**Classificazione Epistemologica:** [Ipotesi pre-registrata] — *Nessuna validità operativa attribuita a priori*  
**Autore:** Antigravity Research Lab  
**Data Pre-Registrazione:** 11 Novembre 2026  
**Stato:** `Ipotesi formulata` (Fase 1 della Pipeline)

---

### 1. Ipotesi Economica, Comportamentale e Strutturale
- **Fenomeno Sottostante:** Disconnessione strutturale tra il prezzo di chiusura della sessione cash USA delle 16:00 EST (22:00 IT) e l'apertura delle 09:30 EST (15:30 IT).
- **Fondamento Comportamentale & Microstrutturale:**
  - *Gap Piccoli ($\le 0.35 \times ATR$):* Generati da squilibri temporanei di inventario durante la sessione notturna europea e asiatica a bassa liquidità. All'apertura del cash USA, l'ingresso dei market maker istituzionali riassorbe l'imbalance riportando il prezzo verso il VWAP della chiusura precedente (**Mean Reversion / Fade**).
  - *Gap Grandi ($\ge 0.80 \times ATR$):* Causati da eventi macroeconomici primari (CPI, NFP, earnings megacap). Non sono rumore di liquidità ma rivalutazioni strutturali del fair value. Il tentativo retail di "chiudere il gap" genera una trappola da liquidazione che spinge il prezzo in forte continuazione (**Momentum / Continuation**).
- **Chi perde:** I trader retail che operano con l'euristica fallace *"i gap si chiudono sempre"*, posizionandosi contro gap guidati da notizie macro fondamentali.

---

### 2. Letteratura Scientifica di Riferimento e Verifica Critica
- **Paper di Riferimento 1:** Lou, D., Polk, C., & Skona, S. (2019). *A Tug of War: Overnight Versus Intraday Expected Returns*. Journal of Financial Economics, 134(1), 192-213.
  - *Cosa dimostra:* Esiste una netta separazione tra i rendimenti generati overnight (guidati da sentiment e retail) e quelli intraday (guidati da ribilanciamento istituzionale).
- **Paper di Riferimento 2:** Branch, B., & Ma, A. (2012). *Overnight Return, the Opening Gap, and the Day Return*. Journal of Financial and Quantitative Analysis.
  - *Cosa dimostra:* La probabilità di chiusura del gap decresce drasticamente all'aumentare dell'ampiezza normalizzata per la volatilità.
- **Verifica Critica & Limiti non Negabili:**
  - *Slippage all'apertura:* I primi 5-15 minuti della sessione cash USA presentano gli spread più ampi della giornata e rischio estremo di *fill execution* negativo.
  - *Regime macro:* Nei regimi di mercato toro a bassa volatilità (es. 2017), i gap-down piccoli vengono chiusi quasi istantaneamente; nei regimi ad alta volatilità (es. 2020 o 2022), i gap possono espandersi per l'intera sessione senza toccare il livello di chiusura precedente.

---

### 3. Mercati e Condizioni Operative
- **Strumento:** Future E-mini S&P 500 (ES) o Micro E-mini (MES), in subordine ETF SPY. Sconsigliati i CFD su indici per via dello spread widening all'apertura.
- **Orario di Trading:** Esclusivamente tra le 15:30 e le 22:00 ora italiana (sessione cash NYSE/Cboe).

---

### 4. Regole Meccaniche di Entrata e Uscita

#### Ramo A — Gap Fade (Mean Reversion su Gap Piccoli)
1. **Condizione di Setup:** Ampiezza Gap:
   $$|P_{open, 15:30} - P_{close, t-1}| \le 0.35 \times ATR(14)_{D1}$$
2. **Filtro di Contesto:** Nessun comunicato macro (CPI, FOMC) rilasciato alle 14:30.
3. **Trigger d'Ingresso (M5):**
   - Se Gap Down: attendere la prima candela a 5 minuti (15:30–15:35) che chiude sopra l'open, entrare Long alla rottura del suo massimo.
   - Se Gap Up: attendere prima candela M5 ribassista, entrare Short alla rottura del minimo.
4. **Target:** Il prezzo di chiusura della sessione precedente ($P_{close, t-1}$).
5. **Stop Loss:** Estremo opposto della candela di trigger $+ 2$ punti ES.

#### Ramo B — Gap Continuation (Breakout su Gap Grandi)
1. **Condizione di Setup:** Ampiezza Gap:
   $$|P_{open, 15:30} - P_{close, t-1}| \ge 0.80 \times ATR(14)_{D1}$$
2. **Trigger d'Ingresso (M5/M15):** Rottura dell'Opening Range dei primi 15 minuti (15:30–15:45) nella direzione del gap.
3. **Target:** $1.5 \times$ l'ampiezza dell'Opening Range oppure uscita oraria alle 21:50.
4. **Stop Loss:** Il lato opposto dell'Opening Range dei primi 15 minuti.

---

### 5. Timeframe e Gestione della Posizione
- **Timeframe di Setup:** D1 (ampiezza gap normalizzata) e M5/M15 (trigger).
- **Time In Force:** Intraday rigoroso. Nessun trade viene mantenuto overnight. Chiusura automatica a mercato alle 21:55 IT.

---

### 6. Gestione del Rischio
- **Rischio per Trade:** $0.50\%$ del capitale per operazione (massimo 1 operazione gap al giorno).
- **Daily Loss Cap:** Se il trade gap viene stoppato, nessun secondo ingresso nella stessa sessione.

---

### 7. Dati Necessari
- Dati storici intraday a 1 minuto (M1) e 5 minuti (M5) del future ES con orari precisi di Regular Trading Hours (RTH 09:30–16:00 EST) e Extended Trading Hours (ETH). Periodo minimo: 2015–2026.

---

### 8. Costi di Transazione e Slippage
- Spread stimato: 0.25 punti ES (\$12.50 per contratto standard, \$1.25 per micro).
- Slippage atteso all'apertura: 0.50 punti ES.
- Commissione broker: \$1.50 per round-turn su micro.
- Impatto sui profitti: Circa $0.15R$ per trade (l'intraday scalping è fortemente sensibile ai costi).

---

### 9. Metriche di Valutazione Attese
- Ramo A (Fade): Win Rate atteso $\approx 65\%$, $R:R \approx 1:0.8$, Expectancy $\approx +0.18R$.
- Ramo B (Continuation): Win Rate atteso $\approx 42\%$, $R:R \approx 1:2.2$, Expectancy $\approx +0.25R$.
- Profit Factor aggregato atteso: $\ge 1.40$.

---

### 10. Criteri di Falsificazione a Freddo
L'ipotesi STR-002 sarà formalmente **respinta e cancellata** se:
1. Al netto dello slippage reale di apertura (0.5 punti ES), l'expectancy del Ramo Fade scende sotto $+0.05R$.
2. Il Win Rate del Ramo Fade scende sotto il $52\%$ su un campione di almeno 200 trade.
3. La continuazione dei Gap Grandi fallisce in più del $60\%$ dei casi in periodo OOS.

---

### 11. Protocollo di Backtesting
- Simulazione con differenziazione rigorosa tra orario ETH ed RTH.
- I fill degli ordini stop devono essere modellati con penalità di slippage empirica derivata dai volumi dei primi 5 minuti di contrattazione.

---

### 12. Validazione Fuori Campione e per Regimi
- **In-Sample:** 2016 – 2021.
- **Out-of-Sample:** 2022 – 2024.
- **Test di Regime:** Scomposizione delle performance tra anni a basso VIX (2017, 2019) e anni ad alto VIX (2020, 2022) per verificare la stabilità dei due rami.
