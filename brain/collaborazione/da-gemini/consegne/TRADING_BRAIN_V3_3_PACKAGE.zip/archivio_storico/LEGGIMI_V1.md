# ISTRUZIONI DI ESECUZIONE ARCHIVIO V1 (Studio 01 Originale)

Questo file documenta la procedura per rieseguire il runner storico `run_comprehensive_simulations_v1.py` al fine di riprodurre byte per byte i risultati originari della V1 (`prop_simulations_raw_v1.json`).

---

## 1. Collegamento tra i file del Motore V1

Il motore originario è archiviato in questa directory come `prop_risk_engine_v1.py`.
Alla riga 13 del file storico `run_comprehensive_simulations_v1.py`, l'istruzione di import originaria recita testualmente:
```python
from prop_risk_engine import PropSimulationScenario, run_full_challenge_experiment, wilson_confidence_interval
```
Per preservare intatto il codice sorgente storico senza alterarne una sola riga, l'esecuzione richiede che `prop_risk_engine` sia risolvibile nell'interprete Python.

---

## 2. Modalità di Esecuzione Verificate

> [!IMPORTANT]
> **Cartella di lavoro e file generato:**
> Il runner genera nella directory corrente di lavoro un file denominato `prop_simulations_raw.json`. Per evitare la sovrascrittura o l'inquinamento dei file storici conservati nell'archivio, si raccomanda di effettuare l'esecuzione all'interno di una cartella temporanea (es. `/tmp/verifica_v1/`).

### Modalità A — Creazione di un collegamento simbolico locale
```bash
# Creazione cartella temporanea isolata
mkdir -p /tmp/verifica_v1
cd /tmp/verifica_v1

# Copia dei sorgenti storici
cp /Users/gioele/.gemini/antigravity/brain/6ad631ed-1ce5-43c2-b93d-20bafa4288f3/brain/collaborazione/da-gemini/consegne-v3.3/archivio_storico/prop_risk_engine_v1.py .
cp /Users/gioele/.gemini/antigravity/brain/6ad631ed-1ce5-43c2-b93d-20bafa4288f3/brain/collaborazione/da-gemini/consegne-v3.3/archivio_storico/run_comprehensive_simulations_v1.py .

# Creazione del symlink per risolvere l'import
ln -s prop_risk_engine_v1.py prop_risk_engine.py

# Esecuzione del runner storico
python3 run_comprehensive_simulations_v1.py

# Verifica dell'hash SHA-256
shasum -a 256 prop_simulations_raw.json
```

### Modalità B — Alias in memoria via wrapper Python (S-03)
Nel modulo `run_comprehensive_simulations_v1.py` la funzione principale di lancio è `run_suite()`. L'alias in `sys.modules` permette di eseguire il runner senza creare collegamenti sul filesystem:
```bash
# Creazione cartella temporanea isolata
mkdir -p /tmp/verifica_v1_b
cd /tmp/verifica_v1_b

# Esecuzione con iniezione del modulo in sys.modules e chiamata alla funzione run_suite()
python3 -c "import sys; sys.path.insert(0, '/Users/gioele/.gemini/antigravity/brain/6ad631ed-1ce5-43c2-b93d-20bafa4288f3/brain/collaborazione/da-gemini/consegne-v3.3/archivio_storico'); import prop_risk_engine_v1 as e; sys.modules['prop_risk_engine'] = e; import run_comprehensive_simulations_v1 as r; r.run_suite()"

# Verifica dell'hash SHA-256
shasum -a 256 prop_simulations_raw.json
```

---

## 3. Output Atteso e Certificazione Crittografica

Entrambe le modalità generano il file `prop_simulations_raw.json` con 10.000 simulazioni per ciascuna delle 24 configurazioni (seed 42).
L'hash SHA-256 risultante deve coincidere identicamente byte per byte con il file archiviato:
```text
a6781b7ea00bf772c11688f0396fbe68ceb8d8d7dc5692022ecc321e326cc081  prop_simulations_raw_v1.json
```
