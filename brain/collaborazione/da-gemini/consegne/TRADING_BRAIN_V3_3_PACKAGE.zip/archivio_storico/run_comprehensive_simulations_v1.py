"""
TRADING RESEARCH LAB — EXPERIMENTAL RUNNER
Script: run_comprehensive_simulations.py
Descrizione: Esegue la suite completa di 10.000 simulazioni Monte Carlo per scenario,
             producendo tabelle con intervalli di confidenza di Wilson al 95%,
             analisi di sensibilità R:R e modellazione dell'effetto cluster (Markov).
"""

import sys
import os
import json

from prop_risk_engine import (
    PropSimulationScenario,
    run_full_challenge_experiment,
    wilson_confidence_interval
)

def run_suite():
    N_SIMS = 10000
    COST_R = 0.05
    MAX_DAYS = 60
    TPD_SWING = 2
    TPD_INTRADAY = 6
    SEED = 42

    # Definizione dei Sistemi Archetipici da confrontare
    systems = {
        "A_Asymmetric_Swing": PropSimulationScenario("Asymmetric Swing (Trend/Breakout)", win_rate=0.35, reward_to_risk=2.5, cost_r=COST_R),
        "B_Balanced_Swing": PropSimulationScenario("Balanced Swing (S&P/FX)", win_rate=0.40, reward_to_risk=2.0, cost_r=COST_R),
        "C_High_WinRate_Scalp": PropSimulationScenario("High Win Rate (Mean Reversion)", win_rate=0.60, reward_to_risk=1.0, cost_r=COST_R),
        "Z_Null_Control": PropSimulationScenario("Null Control (Random Walk)", win_rate=0.50, reward_to_risk=1.0, cost_r=COST_R),
    }

    risks = [0.0025, 0.0050, 0.0075, 0.0100, 0.0150, 0.0200]

    print("=== 1. ANALISI DI SENSIBILITÀ: RISCHIO PER TRADE E SISTEMI (SWING: 2 TRADE/DIE, i.i.d.) ===")
    results_matrix = {}

    for sys_key, scen in systems.items():
        results_matrix[sys_key] = {}
        for r in risks:
            res = run_full_challenge_experiment(
                seed=SEED,
                scenario=scen,
                risk_pct=r,
                trades_per_day=TPD_SWING,
                max_days_per_phase=MAX_DAYS,
                n_simulations=N_SIMS
            )
            results_matrix[sys_key][f"{r:.4f}"] = res
            p_rate = res['pass']['rate']
            p_ci = res['pass']['ci_95']
            ml_rate = res['max_loss']['rate']
            dl_rate = res['daily_loss']['rate']
            to_rate = res['timeout']['rate']
            med_d = res['median_days_pass']
            print(f"[{sys_key}] Risk {r:.2%}: Pass={p_rate:.1%} (CI 95% [{p_ci[0]:.1%}-{p_ci[1]:.1%}]), MaxLoss={ml_rate:.1%}, DailyLoss={dl_rate:.1%}, Timeout={to_rate:.1%}, MedDays={med_d}")

    print("\n=== 2. ANALISI DEI CLUSTER DI PERDITE (MODELLO MARKOV P(L|L)) SUL SISTEMA B (WR 40%, RR 2.0) ===")
    # Nel caso i.i.d., P(L) = 0.60, quindi P(L|L) = 0.60.
    # Testiamo clustering moderato P(L|L)=0.70 e severo P(L|L)=0.80 a Rischio 0.50% e 1.00%
    cluster_results = {}
    for p_ll in [0.60, 0.70, 0.80]:
        cluster_scen = PropSimulationScenario(
            f"Balanced_Markov_PLL_{p_ll}",
            win_rate=0.40,
            reward_to_risk=2.0,
            cost_r=COST_R,
            p_loss_given_loss=p_ll
        )
        cluster_results[f"PLL_{p_ll}"] = {}
        for r in [0.0050, 0.0100]:
            # Test Swing (2 tpd)
            res_sw = run_full_challenge_experiment(SEED, cluster_scen, r, TPD_SWING, MAX_DAYS, N_SIMS)
            # Test Intraday (6 tpd, max 25 giorni)
            res_intra = run_full_challenge_experiment(SEED, cluster_scen, r, TPD_INTRADAY, 25, N_SIMS)
            cluster_results[f"PLL_{p_ll}"][f"risk_{r:.2%}"] = {"swing": res_sw, "intraday": res_intra}
            print(f"P(L|L)={p_ll:.2f} Risk={r:.2%} | Swing Pass={res_sw['pass']['rate']:.1%}, ML={res_sw['max_loss']['rate']:.1%}, DL={res_sw['daily_loss']['rate']:.1%} | Intra Pass={res_intra['pass']['rate']:.1%}, ML={res_intra['max_loss']['rate']:.1%}, DL={res_intra['daily_loss']['rate']:.1%}")

    # Salvataggio dati grezzi JSON per riproducibilità totale
    with open("prop_simulations_raw.json", "w") as f:
        json.dump({"sensitivity": results_matrix, "clustering": cluster_results}, f, indent=2)
    print("\n[OK] Risultati grezzi salvati in prop_simulations_raw.json")

if __name__ == "__main__":
    run_suite()
