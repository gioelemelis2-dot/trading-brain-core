# STR-001 — Time-Series Momentum (TSMOM) Multi-Asset
## Scheda di Ricerca Pre-Registrata (§5.2, §5.3 Master Mission)

**Identificativo:** STR-001  
**Nome Strategia:** Multi-Asset Time-Series Momentum (Trend Following Sistematico)  
**Famiglia:** Trading Direzionale / Trend Following Sistematico  
**Classificazione Epistemologica:** [Ipotesi pre-registrata] — *Nessuna validità operativa attribuita a priori*  
**Autore:** Antigravity Research Lab  
**Data Pre-Registrazione:** 11 Novembre 2026  
**Stato:** `Ipotesi formulata` (Fase 1 della Pipeline)

---

### 1. Ipotesi Economica, Comportamentale e Strutturale
- **Fenomeno Sottostante:** Persistenza direzionale dei prezzi su orizzonti multi-settimanali e mensili (autocorrelazione positiva seriale dei rendimenti a medio termine).
- **Fondamento Comportamentale:**
  - *Underreaction iniziale:* Gli investitori istituzionali e retail elaborano con lentezza le informazioni strutturali e macroeconomiche (conservatism bias, anchoring).
  - *Overreaction successiva & Feedback Loop:* Con il consolidarsi del trend, afflussi di capitale FOMO, ordini di copertura automatica e ribilanciamenti forzati (es. fondi CTA, risk parity) spingono i prezzi oltre il fair value fondamentale.
- **Chi perde e perché non smette:**
  - Partecipanti commerciali / hedger che utilizzano i mercati per trasferire il rischio di prezzo e sono disposti a pagare un premio di assicurazione costante ai fornitori di liquidità trend-following.
  - Trader discrezionali che tentano costantemente di anticipare inversioni (*mean-reversion contrarian*) esaurendo il capitale su falsi massimi/minimi.

---

### 2. Letteratura Scientifica di Riferimento e Verifica Critica
- **Paper Fondativo 1:** Moskowitz, T. J., Ooi, Y. H., & Pedersen, L. H. (2012). *Time series momentum*. Journal of Financial Economics, 104(2), 228-250.
  - *Cosa dimostra:* Rendimenti positivi statisticamente significativi su 58 contratti futures liquidi (equity indices, currencies, commodities, sovereign bonds) su orizzonti di lookback da 1 a 12 mesi.
- **Paper Fondativo 2:** Hurst, B., Ooi, Y. H., & Pedersen, L. H. (2017). *A Century of Evidence on Trend-Following Investing*. Journal of Portfolio Management, 44(1), 15-29.
  - *Cosa dimostra:* Il trend following ha generato alpha costante per oltre un secolo (1880–2016) attraverso quattro macro-fasi storiche.
- **Verifica Critica & Limiti non Negabili:**
  - *Non applicare conclusioni non dimostrate:* Gli studi accademici operano su **futures istituzionali con costi di roll minimi** e ribilanciamento mensile. Non dimostrano affatto che il trend following sia profittevole intraday o su CFD retail gravati da swap notturni elevati.
  - *Il prezzo psicologico:* Il decennio 2011–2019 ha visto i fondi CTA generare rendimenti reali vicini allo zero, con drawdown laterali durati oltre 5 anni. Il trend following richiede una tolleranza brutale a periodi prolungati di *whipsaw* (falsi segnali nei mercati laterali).

---

### 3. Mercati e Condizioni Operative
- **Universo Investibile:** Panier di futures o ETF privi di costo swap tossico:
  - Indici: S&P 500 (ES/MES), Nasdaq (NQ/MNQ), DAX, Nikkei 225.
  - Metalli e Commodities: Oro (GC/MGC), Rame (HG), Petrolio greggio (CL/MCL).
  - Obbligazionario: US 10-Year Treasury (ZN).
  - Valute: EUR/USD (6E), JPY/USD (6J).
- **Condizione Ambientale Necessaria:** Dispersione macroeconomica e ciclo monetario asimmetrico. La strategia è formalmente disabilitata in regimi di compressione prolungata di volatilità (VIX < 12 persistente).

---

### 4. Regole Meccaniche di Entrata e Uscita

#### A. Segnale Direzionale (Lookback Duale)
Per ciascun asset $i$ al giorno $t$:
1. **Trend Primario:** $P_t > SMA(200)_{t}$ (Long) oppure $P_t < SMA(200)_{t}$ (Short).
2. **Momentum di Medio Termino:**
   $$R_{L, t} = \frac{P_t - P_{t-L}}{P_{t-L}}, \quad L = 60 \text{ giorni}$$
   Segnale attivo se $\text{sign}(R_{L, t}) == \text{sign}(P_t - SMA(200)_t)$.
3. **Trigger Operativo:** Donchian Breakout sui massimi/minimi a 20 giorni:
   - Long se $P_t > \max(P_{t-20}, \dots, P_{t-1})$.
   - Short se $P_t < \min(P_{t-20}, \dots, P_{t-1})$.

#### B. Regole di Uscita e Stop
1. **Stop Loss Iniziale Oggettivo:** Calcolato su base volatilità:
   $$Stop_{long} = Entry - 2.5 \times ATR(20)$$
   $$Stop_{short} = Entry + 2.5 \times ATR(20)$$
2. **Trailing Exit:** Uscita per inversione Donchian a 10 giorni ($P_t < \min_{10}$ per i long) o attraversamento inverso della SMA(50).
3. **Nessun Target Fisso:** Si lasciano correre i profitti; l'uscita è demandata unicamente al trailing stop.

---

### 5. Timeframe e Gestione della Posizione
- **Timeframe di Analisi:** Daily (D1) per eliminare il micro-rumore e abbattere il turnover.
- **Esecuzione:** Alla chiusura del mercato cash o all'apertura del giorno successivo tramite ordini stop/limit.
- **Holding Period Atteso:** Da 3 settimane a 4 mesi.

---

### 6. Gestione del Rischio e Position Sizing
- **Volatility Targeting:** Il capitale allocato sul singolo asset è inversamente proporzionale alla sua volatilità realised:
  $$Size_i = \frac{Capitale \times RischioTarget}{2.5 \times ATR_i \times ValorePunto}$$
- **Rischio per Trade:** $0.50\%$ del capitale complessivo per trade.
- **Portfolio Heat Cap:** Massimo $3.0R$ di rischio simultaneo aggregato su tutto il portafoglio.
- **Correlation Cap:** Massimo 1 singola posizione aperta per cluster correlato (es. o Gold o Silver; o EUR/USD o GBP/USD).

---

### 7. Dati Necessari
- Serie storiche giornaliere Daily (OHLCV) corrette per split e dividendi, con backward-ratio adjustment per i contratti futures continui (minimo 15-20 anni di storico: 2005–2026).

---

### 8. Modellazione Costi di Transazione, Spread e Slippage
- **Commissione stimata:** \$2.50 per contratto future micro / \$4.50 per contratto standard.
- **Slippage atteso:** 1 tick per ordine d'ingresso (market on open) e 2 tick su stop loss.
- **Costo di Roll dei futures:** 4 scadenze annue modellate con roll spread storico medio.
- **Penalità totale stimata per trade:** $\approx 0.08R$.

---

### 9. Metriche di Valutazione (§7 Master Mission)
- Expectancy Netta: $E[R] \ge +0.15R$.
- Win Rate atteso: $35\% - 42\%$ (tipico dei sistemi trend-following asimmetrici).
- R-multiplo medio dei vincitori: $\ge 2.8R$.
- Profit Factor netto: $\ge 1.35$.
- Maximum Drawdown in R: $\le 18R$.
- $t$-statistica dell'alpha: $t > 2.5$.

---

### 10. Criteri di Falsificazione a Freddo
L'ipotesi STR-001 sarà formalmente **respinta e archiviata** se:
1. In fase out-of-sample l'expectancy netta scende a $E[R] \le 0.03R$.
2. Il massimo drawdown supera $22R$.
3. Più del $50\%$ del profit factor svanisce applicando costi realistici di roll e slippage.
4. L'edge è presente solo su un singolo asset (es. Nasdaq) e assente sugli altri (mancanza di replicabilità trasversale).

---

### 11. Protocollo di Backtesting
- Motore: Backtest event-driven barra per barra, ordine di esecuzione strictly Next-Bar Open dopo il segnale alla chiusura.
- Nessun bias di look-ahead: tutti gli indicatori (SMA, ATR, Donchian) calcolati con lag $t-1$.

---

### 12. Validazione Fuori Campione e Walk-Forward
- **In-Sample:** 2005 – 2017 (inclusa la crisi 2008 e la ripresa QE).
- **Out-of-Sample Puro:** 2018 – 2023 (incluso il crash pandemico e l'inflazione 2022).
- **Forward Test (Dati recenti):** 2024 – 2026.
- **Walk-Forward:** Finestre rolling di 3 anni di training e 1 anno di test fuori campione.
