#!/usr/bin/env python3
"""
test_prop_risk_v3_3.py
Suite di collaudo unitario, verifica dell'invarianza CRN e validazione analitica per la V3.3 Consolidata.

Copertura test e risoluzione sistematica delle riserve S-01..S-09:
1. Test P-01: Accoppiamento CRN invariante tra sfide (zero sfide che passano solo con il MAE).
2. Test P-02: Generalizzazione MAE browniano a configurazioni multiple (WR 0.50/RR 1.0 e WR 0.40/RR 2.0).
3. Test P-05: Ordine di precedenza uniforme delle barriere a chiusura posizione.
4. Test C-01: Inizializzazione stazionaria della catena di Markov (primo trade campiona da pi).
5. Test C-02: Validazione formale dell'ammissibilita Markov con sollevamento di ValueError.
6. Test C-03: Campionamento ed esecuzione effettiva dello slippage Pareto-Lomax.
7. Test C-12: Regime moderno a giorni illimitati (FTMO post-luglio 2023).
8. Test Q-01: Calcolo IC 95% vs +-1 SE per N=300 trade reali (limite inferiore negativo al 95%).
9. Test Q-02.1 (V12): Regressione bug giorni minimi: congelamento del rischio dopo raggiungimento target (equity invariata).
10. Test Q-02.2 (V04, V08): Precedenza barriere intra-trade su MAE flottante (violazione simultanea -> max_loss, singola -> daily_loss).
11. Test Q-02.3: MAE browniano attraverso il motore con R:R != 2 (RR 1.0, WR 0.50, pavimento 5%, P = 1/6).
12. Test S-02 (V10, V03): MAE profondo attraverso il motore (RR 1.0, WR 0.50, pavimento 7.5%, P esatta = 1/14). Uccide direttamente V10 e V03.
13. Test S-01 / S-02 (V07): Concordanza esatta Fase 2 (0.8572) e prodotto delle due fasi sull'intera sfida (0.6686). Uccide direttamente V07.
14. Test Q-02.5: Concordanza con il calcolo esatto analitico su 5 configurazioni del Gruppo A (tolleranza 4 errori standard).
15. Test S-04 / S-07 (V21): Intervallo di Wilson su valori noti per livelli 90%, 95%, 99% con quantili NormalDist esatti. Uccide V21.
16. Test S-07 (V19, V20): Slippage deterministico e rispetto rigoroso del cap (3.0R). Uccide V19 e V20.
17. Test S-07: Momenti teorici esatti dello slippage Lomax in forma chiusa (E[min(S,c)] = 0.060169R).
18. Test S-07 (V22): Campionamento MAE in prossimita della soglia mu ~ 0 (mu = 2e-7). Uccide V22.
19. Test S-05: Protezione anti-overflow del MAE asimmetrica: scenari estremi calcolabili (WR 0.99 / RR 500) accettati e accurati; rifiuti appropriati.
20. Test S-06: Validazione sistematica degli input fuori dal MAE (NaN, Inf, valori negativi, alpha <= 0, max_days < min_days).
"""

import unittest
import random
import sys
import os
import math
import statistics

sys.path.insert(0, os.path.dirname(__file__))
from prop_risk_engine_v3_3 import (
    PropSimulationScenarioV3_3,
    simulate_phase_v3_3,
    run_full_challenge_v3_3,
    solve_brownian_drift_for_scenario,
    sample_brownian_mae_given_win,
    calculate_kelly_confidence_interval,
    wilson_confidence_interval
)


class ControlledRNG:
    """Generatore deterministico controllato per test unitari mirati."""
    def __init__(self, val: float):
        self.val = val

    def random(self) -> float:
        return self.val


class TestPropRiskV3_3(unittest.TestCase):

    def setUp(self):
        self.base_scen = PropSimulationScenarioV3_3(
            name="Base",
            win_rate=0.40,
            reward_to_risk=2.0,
            cost_r=0.05
        )

    # -------------------------------------------------------------
    # 1. P-01: CRN Coupling
    # -------------------------------------------------------------
    def test_p01_crn_coupling_invariance(self):
        """
        P-01: Dimostra che l'accoppiamento CRN per-sfida impedisce qualsiasi desincronizzazione.
        Il numero di sfide che passano SOLO con il MAE (e falliscono senza MAE) deve essere RIGOROSAMENTE ZERO.
        """
        scen_base = PropSimulationScenarioV3_3("Base_Intra", 0.40, 2.0, cost_r=0.05, use_brownian_mae=False)
        scen_mae = PropSimulationScenarioV3_3("MAE_Intra", 0.40, 2.0, cost_r=0.05, use_brownian_mae=True)

        seed = 42
        n_sims = 2_500
        res_base = run_full_challenge_v3_3(seed, scen_base, risk_pct=0.01, trades_per_day=6, max_days_per_phase=25, n_simulations=n_sims)
        res_mae = run_full_challenge_v3_3(seed, scen_mae, risk_pct=0.01, trades_per_day=6, max_days_per_phase=25, n_simulations=n_sims)

        outcomes_base = res_base["_challenge_outcomes"]
        outcomes_mae = res_mae["_challenge_outcomes"]

        pass_only_mae = 0
        diff_count = 0
        for i in range(n_sims):
            b = outcomes_base[i]
            m = outcomes_mae[i]
            if b != m:
                diff_count += 1
            if m == "pass" and b != "pass":
                pass_only_mae += 1

        self.assertEqual(pass_only_mae, 0, f"Rilevate {pass_only_mae} sfide impossibili (passate con MAE ma fallite senza)!")
        self.assertGreater(diff_count, 0, "Il MAE deve produrre differenze di esito rilevabili")
        self.assertLessEqual(res_mae["pass"]["count"], res_base["pass"]["count"])

    # -------------------------------------------------------------
    # 2. P-02: MAE Generalization
    # -------------------------------------------------------------
    def test_p02_mae_generalization_multi_scenario(self):
        """
        P-02: Verifica generalizzazione analitica del MAE per scenari con WR ed R:R diversi.
        """
        # Configurazione WR=0.50, RR=1.0: P(MAE <= -0.5R | win) = 1/3 ~ 0.3333
        scen_50_1 = PropSimulationScenarioV3_3("WR50_RR1", win_rate=0.50, reward_to_risk=1.0, cost_r=0.0, use_brownian_mae=True)
        self.assertAlmostEqual(scen_50_1.brownian_mu, 0.0, delta=1e-6)

        rng = random.Random(42)
        n = 20_000
        samples_50 = [sample_brownian_mae_given_win(rng, scen_50_1.reward_to_risk, scen_50_1.brownian_mu) for _ in range(n)]
        freq_05_50 = sum(1 for m in samples_50 if m <= -0.50) / n
        self.assertAlmostEqual(freq_05_50, 1.0 / 3.0, delta=0.01)

        # Configurazione Standard WR=0.40, RR=2.0: P(MAE <= -0.5R | win) ~ 0.3981
        scen_40_2 = PropSimulationScenarioV3_3("WR40_RR2", win_rate=0.40, reward_to_risk=2.0, cost_r=0.05, use_brownian_mae=True)
        self.assertAlmostEqual(scen_40_2.brownian_mu, 0.0975, delta=0.001)

        samples_40 = [sample_brownian_mae_given_win(rng, scen_40_2.reward_to_risk, scen_40_2.brownian_mu) for _ in range(n)]
        freq_05_40 = sum(1 for m in samples_40 if m <= -0.50) / n
        self.assertAlmostEqual(freq_05_40, 0.3981, delta=0.01)

    # -------------------------------------------------------------
    # 3. P-05: Barrier Priority Ordering at Close
    # -------------------------------------------------------------
    def test_p05_barrier_priority_ordering(self):
        """
        P-05: Verifica che l'ordine delle barriere a chiusura posizione sia:
        Rovina Assoluta > Max Loss (-10%) > Daily Loss (-5%).
        """
        scen = PropSimulationScenarioV3_3("BarrierTest", 0.01, 1.0, cost_r=0.0)
        rng_out = random.Random(42)
        rng_mae = random.Random(42)
        rng_slip = random.Random(42)

        res, day, eq = simulate_phase_v3_3(
            rng_out, rng_mae, rng_slip,
            scen, risk_pct=0.15, trades_per_day=1, max_days=5, target_pct=0.50, min_days=1
        )
        self.assertEqual(res, "max_loss", f"Violazione simultanea a chiusura deve restituire 'max_loss', ottenuto: {res}")

    # -------------------------------------------------------------
    # 4. C-01: Markov Stationary Start
    # -------------------------------------------------------------
    def test_c01_markov_stationary_start(self):
        """C-01: Verifica che il primo trade campioni lo stato da pi (frequenza vittoria = 40% non 70%)."""
        scen_markov = PropSimulationScenarioV3_3("Markov", 0.40, 2.0, cost_r=0.05, p_loss_given_loss=0.80)
        rng_out = random.Random(42)
        rng_mae = random.Random(42)
        rng_slip = random.Random(42)

        n = 25_000
        losses = 0
        for _ in range(n):
            res, _, eq = simulate_phase_v3_3(rng_out, rng_mae, rng_slip, scen_markov, 0.01, 1, 1, 0.10, min_days=1)
            if eq < 0:
                losses += 1
        p_loss_first = losses / n
        self.assertAlmostEqual(p_loss_first, 0.60, delta=0.01)

    # -------------------------------------------------------------
    # 5. C-02: Markov Admissibility
    # -------------------------------------------------------------
    def test_c02_markov_admissibility(self):
        """C-02: Verifica che parametri non ammissibili sollevino ValueError."""
        with self.assertRaises(ValueError):
            PropSimulationScenarioV3_3("Invalid", 0.40, 2.0, p_loss_given_loss=0.20)

    # -------------------------------------------------------------
    # 6. C-03: Slippage Execution
    # -------------------------------------------------------------
    def test_c03_slippage_execution(self):
        """C-03: Verifica che lo slippage sia eseguito e riduca il tasso di passaggio."""
        scen_no_slip = PropSimulationScenarioV3_3("NoSlip", 0.40, 2.0, cost_r=0.05)
        scen_slip = PropSimulationScenarioV3_3("Slip", 0.40, 2.0, cost_r=0.05, slippage_tail_alpha=1.8, slippage_scale=0.05, slippage_cap_r=3.0)

        r_no = run_full_challenge_v3_3(42, scen_no_slip, 0.01, 2, 60, 1000)
        r_slip = run_full_challenge_v3_3(42, scen_slip, 0.01, 2, 60, 1000)

        self.assertGreater(r_no["pass"]["rate"], r_slip["pass"]["rate"])

    # -------------------------------------------------------------
    # 7. C-12: Unlimited Days FTMO
    # -------------------------------------------------------------
    def test_c12_unlimited_days_ftmo(self):
        """C-12: Verifica che max_days=None azzeri i timeout e porti il pass rate al 99% a rischio 0.25%."""
        r = run_full_challenge_v3_3(42, self.base_scen, 0.0025, 2, None, 1000)
        self.assertEqual(r["timeout"]["count"], 0)
        self.assertGreater(r["pass"]["rate"], 0.98)

    # -------------------------------------------------------------
    # 8. Q-01: Kelly Confidence Interval (95% vs 68%)
    # -------------------------------------------------------------
    def test_q01_kelly_confidence_interval_at_95_and_68(self):
        """
        Q-01: Verifica calcolo analitico dell'intervallo di confidenza dell'edge:
        - A livello 95% con N=300: il limite inferiore DEVE essere strettamente negativo (<0).
        - A livello +-1 SE (~68.27%) con N=300: l'intervallo e [+0.065, +0.235].
        """
        exp_r, se, ci_low_95, ci_high_95 = calculate_kelly_confidence_interval(
            n_trades=300,
            win_rate=0.40,
            reward_to_risk=2.0,
            cost_r=0.05,
            confidence_level=0.95
        )
        self.assertAlmostEqual(exp_r, 0.150, places=3)
        self.assertAlmostEqual(se, 0.08485, places=4)
        self.assertLess(ci_low_95, 0.0)
        self.assertGreater(ci_high_95, 0.0)
        self.assertAlmostEqual(ci_low_95, -0.0163, delta=0.001)
        self.assertAlmostEqual(ci_high_95, +0.3163, delta=0.001)

        # Calcolo a +-1 SE (~68.27%)
        _, _, ci_low_68, ci_high_68 = calculate_kelly_confidence_interval(
            n_trades=300,
            win_rate=0.40,
            reward_to_risk=2.0,
            cost_r=0.05,
            confidence_level=0.682689492137086
        )
        self.assertGreater(ci_low_68, 0.0)
        self.assertAlmostEqual(ci_low_68, 0.0651, delta=0.001)
        self.assertAlmostEqual(ci_high_68, 0.2349, delta=0.001)

    # -------------------------------------------------------------
    # 9. Q-02.1 (V12 Mutant): Regression Test for min_days Risk Freeze
    # -------------------------------------------------------------
    def test_q02_min_days_regression_freezes_risk(self):
        """
        Q-02.1 (Uccisione mutante V12):
        Verifica che una volta raggiunto il target al giorno 1,
        il sistema NON prenda ulteriori trade a rischio nei giorni 2, 3, 4,
        uscendo con esito 'pass' e equity esattamente identica al target (+0.10).
        """
        scen_win = PropSimulationScenarioV3_3("TargetInstant", win_rate=1.0 - 1e-9, reward_to_risk=2.0, cost_r=0.0)
        rng = random.Random(42)

        res, day, eq = simulate_phase_v3_3(
            rng_outcome=rng,
            rng_mae=rng,
            rng_slippage=rng,
            scenario=scen_win,
            risk_pct=0.05,
            trades_per_day=4,
            max_days=30,
            target_pct=0.10,
            min_days=4
        )

        self.assertEqual(res, "pass")
        self.assertEqual(day, 4)
        self.assertAlmostEqual(eq, 0.10, places=4)

    # -------------------------------------------------------------
    # 10. Q-02.2 (V04 & V08 Mutants): Intra-trade Barrier Hierarchy
    # -------------------------------------------------------------
    def test_q02_barrier_priority_during_trade_mae(self):
        """
        Q-02.2 (Uccisione mutanti V04 e V08):
        Verifica che l'ordine delle barriere sia rigorosamente applicato durante il trade (intra-trade MAE):
        - Caso 1: MAE profondo che viola simultaneamente Max Loss e Daily Loss -> esito 'max_loss'.
        - Caso 2: MAE che viola Daily Loss ma NON Max Loss -> esito 'daily_loss'.
        """
        scen = PropSimulationScenarioV3_3("Base", 0.40, 2.0, cost_r=0.05, use_brownian_mae=True)

        # Caso 1: Violazione congiunta Max Loss (-10%) e Daily Loss (-5%) -> max_loss
        res1, day1, eq1 = simulate_phase_v3_3(
            rng_outcome=ControlledRNG(0.1),
            rng_mae=ControlledRNG(1e-6),
            rng_slippage=ControlledRNG(0.5),
            scenario=scen,
            risk_pct=0.15,
            trades_per_day=1,
            max_days=5,
            target_pct=0.50,
            min_days=1
        )
        self.assertEqual(res1, "max_loss", f"Violazione simultanea intra-trade deve dare 'max_loss', ottenuto: {res1}")

        # Caso 2: Violazione solo di Daily Loss (-5%) -> daily_loss
        res2, day2, eq2 = simulate_phase_v3_3(
            rng_outcome=ControlledRNG(0.1),
            rng_mae=ControlledRNG(1e-6),
            rng_slippage=ControlledRNG(0.5),
            scenario=scen,
            risk_pct=0.08,
            trades_per_day=1,
            max_days=5,
            target_pct=0.50,
            min_days=1
        )
        self.assertEqual(res2, "daily_loss", f"Violazione solo daily loss intra-trade deve dare 'daily_loss', ottenuto: {res2}")

    # -------------------------------------------------------------
    # 11. Q-02.3: MAE through Engine with RR != 2
    # -------------------------------------------------------------
    def test_q02_mae_through_engine_rr_diff_2(self):
        """
        Q-02.3: MAE browniano attraverso il motore con R:R != 2 (configurazione WR=0.50, RR=1.0, pavimento 5%).
        Violazione avviene se MAE <= -0.50. P(MAE <= -0.50 | win) = 1/3, P(daily_loss) = 1/6 (~0.1667).
        """
        scen = PropSimulationScenarioV3_3("WR50_RR1", 0.50, 1.0, cost_r=0.0, use_brownian_mae=True)
        n = 10_000
        rng_out = random.Random(42)
        rng_mae = random.Random(1042)
        rng_slip = random.Random(2042)

        daily_loss_trade1 = 0
        for _ in range(n):
            res, day, eq = simulate_phase_v3_3(
                rng_out, rng_mae, rng_slip,
                scen, risk_pct=0.10, trades_per_day=1, max_days=1, target_pct=0.50, min_days=1
            )
            if res == "daily_loss":
                daily_loss_trade1 += 1

        rate = daily_loss_trade1 / n
        expected = 1.0 / 6.0
        se = math.sqrt(expected * (1.0 - expected) / n)
        z = abs(rate - expected) / se
        self.assertLess(z, 3.0)

    # -------------------------------------------------------------
    # 12. S-02 (V10 & V03 Mutants): Deep MAE through Engine
    # -------------------------------------------------------------
    def test_mae_profondo_attraverso_motore_rr1(self):
        """
        S-02 (Uccisione mutanti V10 e V03):
        Test del MAE profondo attraverso il motore con pavimento daily loss al 7.5% (max_daily_loss_pct=0.075).
        A rischio 10%, la violazione intra-trade scatta se floating <= -0.075 <=> MAE <= -0.75R.
        Per WR=0.50, RR=1.0 (mu=0), F(0.75) = (1 - 0.75) / (1 + 0.75) = 0.25 / 1.75 = 1/7.
        Probabilita teorica esatta: P(win) * F(0.75) = 0.50 * 1/7 = 1/14 (~0.0714286).
        
        Mutante V10 (tronca MAE a -0.50): non puo mai raggiungere -0.75, quindi produce P = 0 -> UCCISO!
        Mutante V03 (hardcoded RR=2): produce probabilità differente -> UCCISO!
        """
        scen = PropSimulationScenarioV3_3("RR1_Deep", 0.50, 1.0, cost_r=0.0, use_brownian_mae=True)
        n = 10_000
        rng_out = random.Random(42)
        rng_mae = random.Random(1042)
        rng_slip = random.Random(2042)

        dl_count = 0
        for _ in range(n):
            res, _, _ = simulate_phase_v3_3(
                rng_out, rng_mae, rng_slip,
                scen, risk_pct=0.10, trades_per_day=1, max_days=1, target_pct=0.50,
                max_daily_loss_pct=0.075, min_days=1
            )
            if res == "daily_loss":
                dl_count += 1

        rate = dl_count / n
        expected = 1.0 / 14.0
        se = math.sqrt(expected * (1.0 - expected) / n)
        z = abs(rate - expected) / se
        self.assertLess(z, 3.0, f"Frequenza MAE profondo non concorde con calcolo esatto: rate={rate:.4f}, exp={expected:.4f}, z={z:.2f}")

    # -------------------------------------------------------------
    # 13. S-01 / S-02 (V07 Mutant): Exact Phase 2 & Two-Phase Product
    # -------------------------------------------------------------
    def test_fase2_esatta_e_prodotto_due_fasi(self):
        """
        S-01 / S-02 (Uccisione mutante V07):
        Verifica concordanza della probabilita della singola Fase 2 e della sfida a due fasi
        contro i benchmark analitici esatti (programmazione dinamica sul reticolo):
        - Fase 1 isolata (target 10%, swing 60d): 0.7800 (esatto)
        - Fase 2 isolata (target 5%, swing 60d): 0.8572 (esatto, S-01)
        - Sfida intera (prodotto due fasi): 0.7800 * 0.8572 = 0.6686 (esatto Gruppo A)
        
        Passa attraverso run_full_challenge_v3_3, uccidendo direttamente il mutante V07!
        """
        scen = PropSimulationScenarioV3_3("Base", 0.40, 2.0, cost_r=0.05)
        n = 3_000

        # 1. Verifica Fase 2 isolata contro benchmark esatto 0.8572
        rng_out = random.Random(42)
        rng_mae = random.Random(142)
        rng_slip = random.Random(242)

        p2_sim = sum(1 for _ in range(n) if simulate_phase_v3_3(rng_out, rng_mae, rng_slip, scen, 0.01, 2, 60, target_pct=0.05, min_days=4)[0] == "pass") / n
        p2_exact = 0.8572
        se2 = math.sqrt(p2_exact * (1.0 - p2_exact) / n)
        z2 = abs(p2_sim - p2_exact) / se2
        self.assertLess(z2, 4.0, f"Fase 2 scostamento da esatto analitico (0.8572) troppo elevato: z={z2:.2f}")

        # 2. Verifica sfida a due fasi attraverso run_full_challenge_v3_3 contro 0.6686 (uccide V07)
        res_full = run_full_challenge_v3_3(42, scen, risk_pct=0.01, trades_per_day=2, max_days_per_phase=60, n_simulations=n)
        p_full_sim = res_full["pass"]["rate"]
        p_full_exact = 0.6686
        se_full = math.sqrt(p_full_exact * (1.0 - p_full_exact) / n)
        z_full = abs(p_full_sim - p_full_exact) / se_full
        self.assertLess(z_full, 4.0, f"Sfida due fasi scostamento da esatto analitico (0.6686) troppo elevato: z={z_full:.2f}")

    # -------------------------------------------------------------
    # 14. Q-02.5: Full Group A Multi-Configuration Concordance
    # -------------------------------------------------------------
    def test_q02_exact_concordance_group_a_multi_config(self):
        """
        Q-02.5: Concordanza con il calcolo esatto analitico sulle configurazioni del Gruppo A:
        1. Senza limite di tempo, rischio 0.50%: Esatto = 0.9108
        2. Senza limite di tempo, rischio 1.00%: Esatto = 0.7034
        3. Swing 1%, 60 giorni: Esatto = 0.6686
        4. Markov P(L|L)=0.80 partenza stazionaria, swing 1%, 60 giorni: Esatto = 0.4406
        5. Intraday 1%, 25 giorni con MAE browniano: Esatto = 0.3884
        Tolleranza statistica: 4 errori standard.
        """
        scen_base = PropSimulationScenarioV3_3("Base", 0.40, 2.0, cost_r=0.05)
        scen_markov = PropSimulationScenarioV3_3("Markov", 0.40, 2.0, cost_r=0.05, p_loss_given_loss=0.80)
        scen_mae = PropSimulationScenarioV3_3("MAE_Intra", 0.40, 2.0, cost_r=0.05, use_brownian_mae=True)

        configs = [
            ("Unlimited 0.50%", scen_base,   0.0050, 2, None, 0.9108, 3_000),
            ("Unlimited 1.00%", scen_base,   0.0100, 2, None, 0.7034, 3_000),
            ("60d Swing 1.00%", scen_base,   0.0100, 2, 60,   0.6686, 3_000),
            ("Markov Swing 1%", scen_markov, 0.0100, 2, 60,   0.4406, 3_000),
            ("Intraday 1% MAE", scen_mae,    0.0100, 6, 25,   0.3884, 3_000),
        ]

        for name, scen, risk, trades, days, p_exact, n in configs:
            res = run_full_challenge_v3_3(42, scen, risk, trades, days, n)
            rate = res["pass"]["rate"]
            se = math.sqrt(p_exact * (1.0 - p_exact) / n)
            z = abs(rate - p_exact) / se
            self.assertLess(z, 4.0, f"{name}: z-score={z:.2f} supera tolleranza di 4 errori standard (rate={rate}, exact={p_exact})")

    # -------------------------------------------------------------
    # 15. S-04 / S-07 (V21 Mutant): Wilson Known Values Across Levels
    # -------------------------------------------------------------
    def test_wilson_valori_noti(self):
        """
        S-04 / S-07 (Uccisione mutante V21):
        Verifica che wilson_confidence_interval calcoli i quantili esatti per livelli diversi da 0.95.
        Per k = 50, n = 100:
        - 90% (z = 1.64485): [0.4188, 0.5812]
        - 95% (z = 1.95996): [0.4038, 0.5962]
        - 99% (z = 2.57583): [0.3753, 0.6247]
        
        Mutante V21 (z = 1 hardcoded): fallisce all'istante su tutti i livelli!
        Inoltre verifica che livelli fuori da (0, 1) sollevino ValueError.
        """
        # Livello 90%
        low90, high90 = wilson_confidence_interval(50, 100, 0.90)
        self.assertAlmostEqual(low90, 0.4188, delta=0.0005)
        self.assertAlmostEqual(high90, 0.5812, delta=0.0005)

        # Livello 95%
        low95, high95 = wilson_confidence_interval(50, 100, 0.95)
        self.assertAlmostEqual(low95, 0.4038, delta=0.0005)
        self.assertAlmostEqual(high95, 0.5962, delta=0.0005)

        # Livello 99%
        low99, high99 = wilson_confidence_interval(50, 100, 0.99)
        self.assertAlmostEqual(low99, 0.3753, delta=0.0005)
        self.assertAlmostEqual(high99, 0.6247, delta=0.0005)

        # Validazione limiti
        with self.assertRaises(ValueError):
            wilson_confidence_interval(50, 100, 0.0)
        with self.assertRaises(ValueError):
            wilson_confidence_interval(50, 100, 1.0)
        with self.assertRaises(ValueError):
            wilson_confidence_interval(50, 100, -0.5)

    # -------------------------------------------------------------
    # 16. S-07 (V19 & V20 Mutants): Deterministic Slippage & Cap Enforcement
    # -------------------------------------------------------------
    def test_slippage_deterministico(self):
        """
        S-07 (Uccisione mutanti V19 e V20):
        Verifica deterministica della formula di campionamento Lomax e del rispetto del cap:
        raw_slip = ((1 - u)^(-1 / alpha) - 1) * scale.
        
        Per alpha = 1.8, scale = 0.05, cap = 3.0:
        - Con u = 0.5: raw_slip = (2^(1/1.8) - 1) * 0.05 = (1.469734 - 1) * 0.05 = 0.0234867R.
          (Mutante V19 usa -alpha = -1.8, dando 0.12411R -> UCCISO!)
        - Con u = 1 - 1e-12: raw_slip = 232082R >> 3.0R.
          Verifica che slip sia rigidamente troncato a cap = 3.0R.
          (Mutante V20 ignora il cap -> UCCISO!)
        """
        scen_slip = PropSimulationScenarioV3_3(
            "SlipDet", 0.01, 1.0, cost_r=0.0,
            slippage_tail_alpha=1.8, slippage_scale=0.05, slippage_cap_r=3.0
        )

        # Test u = 0.5 (Verifica esponente -1/alpha contro -alpha di V19)
        # In simulate_phase, per trade perdente, r_gross = -1.0 - slip. equity += r_net * risk_pct.
        # Con risk_pct = 1.0, cost_r = 0.0, una perdita produce equity = -1.0 - slip.
        res1, _, eq1 = simulate_phase_v3_3(
            rng_outcome=ControlledRNG(0.9), # perdita
            rng_mae=ControlledRNG(0.5),
            rng_slippage=ControlledRNG(0.5), # u = 0.5
            scenario=scen_slip,
            risk_pct=0.01, # risk 1%
            trades_per_day=1,
            max_days=1,
            target_pct=0.50,
            min_days=1
        )
        # r_net = -1.0 - 0.0234867 = -1.0234867. equity = -0.010234867
        expected_slip = ((1.0 - 0.5) ** (-1.0 / 1.8) - 1.0) * 0.05 # 0.0234867
        expected_eq = (-1.0 - expected_slip) * 0.01
        self.assertAlmostEqual(eq1, expected_eq, places=7, msg="Lo slippage per u=0.5 deve coincidere esattamente con la formula Lomax")

        # Test u -> 1 (Verifica rispetto del cap = 3.0R contro V20)
        res2, _, eq2 = simulate_phase_v3_3(
            rng_outcome=ControlledRNG(0.9),
            rng_mae=ControlledRNG(0.5),
            rng_slippage=ControlledRNG(1.0 - 1e-12), # u estremo
            scenario=scen_slip,
            risk_pct=0.01,
            trades_per_day=1,
            max_days=1,
            target_pct=0.50,
            min_days=1
        )
        # Con cap a 3.0R: r_net = -1.0 - 3.0 = -4.0. equity = -0.04
        self.assertAlmostEqual(eq2, -0.04, places=6, msg="Lo slippage estremo deve essere limitato esattamente a cap = 3.0R")

    # -------------------------------------------------------------
    # 17. S-07: Slippage Moments against Exact Closed-Form
    # -------------------------------------------------------------
    def test_momenti_slippage_forma_chiusa(self):
        """
        S-07: Verifica della media campionaria dello slippage contro il momento teorico esatto in forma chiusa:
        E[min(S, c)] = lambda / (alpha - 1) * [1 - (1 + c/lambda)^(1 - alpha)].
        Per alpha = 1.8, lambda = 0.05, c = 3.0:
        E[min(S, c)] = 0.05 / 0.8 * [1 - 61^(-0.8)] = 0.060169R.
        """
        alpha = 1.8
        scale = 0.05
        cap = 3.0
        exact_e_s = (scale / (alpha - 1.0)) * (1.0 - (1.0 + cap / scale) ** (1.0 - alpha))
        self.assertAlmostEqual(exact_e_s, 0.060169, places=6)

        # Campionamento Monte Carlo
        rng = random.Random(42)
        n = 50_000
        draws = []
        for _ in range(n):
            u = rng.random()
            raw = ((1.0 - u) ** (-1.0 / alpha) - 1.0) * scale
            draws.append(min(cap, max(0.0, raw)))

        mean_s = statistics.mean(draws)
        se = statistics.stdev(draws) / math.sqrt(n)
        z = abs(mean_s - exact_e_s) / se
        self.assertLess(z, 3.0, f"Media campionaria slippage non concorde con valore teorico esatto: mean={mean_s:.6f}, exact={exact_e_s:.6f}, z={z:.2f}")

    # -------------------------------------------------------------
    # 18. S-07 (V22 Mutant): MAE Sampler Threshold mu ~ 0
    # -------------------------------------------------------------
    def test_mae_soglia_mu_quasi_zero(self):
        """
        S-07 (Uccisione mutante V22):
        Verifica del campionatore con mu = 2e-7 (appena sopra la soglia 1e-7).
        Il campionatore deve utilizzare la formula generale con deriva e coincidere con F(d) analitica.
        """
        mu_small = 2e-7
        rr = 1.0
        rng = random.Random(42)
        n = 20_000
        samples = [sample_brownian_mae_given_win(rng, rr, mu_small) for _ in range(n)]
        freq_05 = sum(1 for m in samples if m <= -0.50) / n
        # Per mu -> 0 con RR=1.0, F(0.50) -> 1/3 ~ 0.333333
        self.assertAlmostEqual(freq_05, 1.0 / 3.0, delta=0.015)

    # -------------------------------------------------------------
    # 19. S-05: MAE Asymmetric Guards & Extreme Values
    # -------------------------------------------------------------
    def test_s05_mae_asymmetric_guards_extreme_values(self):
        """
        S-05: Verifica della protezione anti-overflow asimmetrica:
        - Per mu > 0: exp(-2*mu*RR) va in underflow pulito a 0.0 senza errori per RR grande.
          Configurazioni calcolabili come WR=0.99, RR=500 (mu ~ 2.3026, 2*mu ~ 4.6 < 700) devono essere accettate.
        - Precisione della deriva risolta: |P_win(mu) - WR| < 1e-12.
        - Campionatore coerente con F(d) analitica esatta entro 4 SE.
        """
        # Configurazione estrema ammissibile
        scen_ext = PropSimulationScenarioV3_3("WR99_RR500", win_rate=0.99, reward_to_risk=500.0, use_brownian_mae=True)
        self.assertAlmostEqual(scen_ext.brownian_mu, 2.302585, delta=1e-5)

        # Verifica fedelta di ricostruzione del win rate
        mu = scen_ext.brownian_mu
        p_reprod = (1.0 - math.exp(2.0 * mu)) / (math.exp(-2.0 * mu * 500.0) - math.exp(2.0 * mu))
        self.assertAlmostEqual(p_reprod, 0.99, delta=1e-10)

        # Verifica campionamento contro quantili di F(d)
        rng = random.Random(42)
        n = 10_000
        samples = [sample_brownian_mae_given_win(rng, 500.0, mu) for _ in range(n)]
        # Per d = 0.5: F(0.5) = [1 - exp(-2*mu*500)]*(exp(2*mu*1) - exp(2*mu*0.5)) / [(exp(2*mu*0.5) - exp(-2*mu*500))*(exp(2*mu*1) - 1)]
        arg_b = -2.0 * mu * 500.0
        exp_neg_b = math.exp(arg_b) if arg_b > -700.0 else 0.0
        exact_f_05 = (-math.expm1(arg_b) * (math.exp(2*mu) - math.exp(mu))) / ((math.exp(mu) - exp_neg_b) * math.expm1(2*mu))
        emp_05 = sum(1 for s in samples if s <= -0.50) / n
        se = math.sqrt(exact_f_05 * (1.0 - exact_f_05) / n)
        z = abs(emp_05 - exact_f_05) / se
        self.assertLess(z, 4.0)

    # -------------------------------------------------------------
    # 20. S-06: Comprehensive Input Validation
    # -------------------------------------------------------------
    def test_s06_comprehensive_input_validation(self):
        """
        S-06: Validazione sistematica degli input fuori dal MAE.
        Verifica che sollevino determinatamente ValueError:
        - Valori non finiti (NaN, Inf);
        - cost_r negativo;
        - alpha <= 0, scale <= 0, cap <= 0;
        - risk_pct fuori da (0, 1) o negativo;
        - trades_per_day < 1;
        - max_days < min_days.
        """
        # 1. NaN e Inf nel costruttore dello scenario
        with self.assertRaises(ValueError):
            PropSimulationScenarioV3_3("NaN_RR", win_rate=0.40, reward_to_risk=float("nan"))
        with self.assertRaises(ValueError):
            PropSimulationScenarioV3_3("Inf_RR", win_rate=0.40, reward_to_risk=float("inf"))
        with self.assertRaises(ValueError):
            PropSimulationScenarioV3_3("NaN_Cost", win_rate=0.40, reward_to_risk=2.0, cost_r=float("nan"))
        with self.assertRaises(ValueError):
            PropSimulationScenarioV3_3("NegCost", win_rate=0.40, reward_to_risk=2.0, cost_r=-0.05)

        # 2. Parametri di slippage non validi
        with self.assertRaises(ValueError):
            PropSimulationScenarioV3_3("AlphaZero", 0.40, 2.0, slippage_tail_alpha=0.0)
        with self.assertRaises(ValueError):
            PropSimulationScenarioV3_3("ScaleNeg", 0.40, 2.0, slippage_scale=-0.05)
        with self.assertRaises(ValueError):
            PropSimulationScenarioV3_3("CapZero", 0.40, 2.0, slippage_cap_r=0.0)

        # 3. Parametri di simulazione non validi in simulate_phase_v3_3
        scen = self.base_scen
        rng = random.Random(42)

        # risk_pct negativo o >= 1
        with self.assertRaises(ValueError):
            simulate_phase_v3_3(rng, rng, rng, scen, risk_pct=-0.01, trades_per_day=1, max_days=10, target_pct=0.10)
        with self.assertRaises(ValueError):
            simulate_phase_v3_3(rng, rng, rng, scen, risk_pct=1.0, trades_per_day=1, max_days=10, target_pct=0.10)
        with self.assertRaises(ValueError):
            simulate_phase_v3_3(rng, rng, rng, scen, risk_pct=float("nan"), trades_per_day=1, max_days=10, target_pct=0.10)

        # trades_per_day < 1
        with self.assertRaises(ValueError):
            simulate_phase_v3_3(rng, rng, rng, scen, risk_pct=0.01, trades_per_day=0, max_days=10, target_pct=0.10)

        # max_days < min_days (es. max_days=3, min_days=4)
        with self.assertRaises(ValueError):
            simulate_phase_v3_3(rng, rng, rng, scen, risk_pct=0.01, trades_per_day=1, max_days=3, target_pct=0.10, min_days=4)

        # 4. Parametri non validi in calculate_kelly_confidence_interval
        with self.assertRaises(ValueError):
            calculate_kelly_confidence_interval(300, 0.40, 2.0, confidence_level=0.0)
        with self.assertRaises(ValueError):
            calculate_kelly_confidence_interval(300, 0.40, 2.0, confidence_level=1.0)
        with self.assertRaises(ValueError):
            calculate_kelly_confidence_interval(0, 0.40, 2.0, confidence_level=0.95)


if __name__ == "__main__":
    unittest.main()
