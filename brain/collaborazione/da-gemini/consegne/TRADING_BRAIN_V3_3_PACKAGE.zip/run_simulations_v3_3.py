#!/usr/bin/env python3
"""
run_simulations_v3_3.py
Esecutore delle simulazioni Monte Carlo del Trading Brain (Versione 3.3 Consolidata).
Accoppiamento CRN invariante per-sfida e per-fase con zero desincronizzazioni.

Risoluzione sistematica delle riserve S-01..S-09 di Claude Code.
"""

import os
import json
import random
import statistics
from typing import Dict, Any, List

from prop_risk_engine_v3_3 import (
    PropSimulationScenarioV3_3,
    run_full_challenge_v3_3,
    calculate_kelly_confidence_interval
)

SEED = 42
N_SIMS = 10_000
COST_R = 0.05


def main():
    print("=== AVVIO SIMULAZIONI QUANTITATIVE V3.3 CONSOLIDATE (CRN INVARIANTE) ===")
    print(f"Parametri Globali: Seed={SEED}, Simulazioni per scenario={N_SIMS:,}, Costo={COST_R}R")

    # Scenari V3.3
    scen_iid = PropSimulationScenarioV3_3("Balanced_i.i.d.", win_rate=0.40, reward_to_risk=2.0, cost_r=COST_R)
    scen_mae = PropSimulationScenarioV3_3("Balanced_Brownian_MAE", win_rate=0.40, reward_to_risk=2.0, cost_r=COST_R, use_brownian_mae=True)
    scen_slip = PropSimulationScenarioV3_3("Balanced_Pareto_Slip", win_rate=0.40, reward_to_risk=2.0, cost_r=COST_R, slippage_tail_alpha=1.8, slippage_scale=0.05, slippage_cap_r=3.0)
    scen_markov = PropSimulationScenarioV3_3("Balanced_Markov_Cluster", win_rate=0.40, reward_to_risk=2.0, cost_r=COST_R, p_loss_given_loss=0.80)

    # Q-01: Calcolo IC esatto per N=300 trade reali tramite NormalDist
    exp_r, se_r, ci_low_95, ci_high_95 = calculate_kelly_confidence_interval(300, 0.40, 2.0, COST_R, confidence_level=0.95)
    _, _, ci_low_68, ci_high_68 = calculate_kelly_confidence_interval(300, 0.40, 2.0, COST_R, confidence_level=0.682689492137086)

    # Metadati epistemologici arricchiti nel JSON (S-01, S-04, S-05, S-07, S-08, S-09)
    results: Dict[str, Any] = {
        "metadata": {
            "version": "3.3.0",
            "seed": SEED,
            "n_simulations": N_SIMS,
            "cost_r": COST_R,
            "engine": "prop_risk_engine_v3_3.py",
            "epistemological_status": {
                "edge_hypothesis": "[EDGE SUPPOSTO] +0.15R netto (+0.20R lordo - 0.05R costi)",
                "independence_hypothesis": "[IPOTESI i.i.d.] Assenza di autocorrelazione se non diversamente specificato",
                "mae_model": "[SIMULATO - ILLUSTRATIVO] Modello browniano continuo condizionato a target. Benchmark analitici esatti (programmazione dinamica sul reticolo con F(d) in forma chiusa): Intraday 1%: Pass delta -2.42 pt, Daily Loss delta +2.58 pt, Max Loss delta -0.12 pt; Swing 1%: Pass delta -1.53 pt (Q-04, S-01, S-08)",
                "slippage_model": "[SIMULATO - ILLUSTRATIVO] Lomax alpha=1.8, scale=0.05R, cap=3.0R. Momenti teorici esatti in forma chiusa: E[min(S,c)]=0.060169R, Var[min(S,c)]=0.022249, E[R_net]=0.113899R, Var[R]=2.260861, f*=0.3363% (Q-03, S-07)",
                "two_phase_challenge_benchmarks": {
                    "phase1_isolated_exact": 0.7800,
                    "phase2_isolated_exact": 0.8572,
                    "combined_two_phase_exact": 0.6686,
                    "method": "Programmazione dinamica esatta sul reticolo (c1_esatto_challenge.fase) - S-01"
                },
                "model_stylized_assumptions": {
                    "assumption_1_overnight": "Nessuna posizione aperta a mezzanotte (il pavimento di perdita giornaliera e calcolato sull'equity chiusa a mezzanotte) - S-09",
                    "assumption_2_sequential_trades": "Trade strettamente sequenziali, mai sovrapposti contemporaneamente a mercato - S-09",
                    "assumption_3_markov_reinitialization": "Re-inizializzazione stazionaria all'inizio di ciascuna fase della sfida - S-09",
                    "assumption_4_target_lock": "Al raggiungimento del target prima di min_days, operativita simbolica a rischio zero fino al completamento dei giorni minimi - S-09"
                },
                "kelly_confidence_interval": {
                    "sample_size": 300,
                    "expected_return_r": round(exp_r, 4),
                    "standard_error_r": round(se_r, 4),
                    "pm_1_standard_error_68pct": [round(ci_low_68, 4), round(ci_high_68, 4)],
                    "confidence_interval_95pct": [round(ci_low_95, 4), round(ci_high_95, 4)],
                    "statistical_conclusion": "Al 95% l'intervallo contiene ampiamente lo zero (limite inferiore -0.0163R < 0): l'edge non e distinguibile da zero su 300 trade reali (Q-01)"
                },
                "prop_regulation_source": "[FONTE ESTERNA V-SEC] Regolamento FTMO post-13/07/2023: periodo illimitato (senza scadenza temporale), dati di policy esterna non verificati direttamente in sessione (S-08)"
            }
        },
        "modern_unlimited_days": {},
        "legacy_fixed_days": {},
        "paired_crn_mae_impact": {},
        "paired_crn_slippage_impact": {},
        "markov_clustering_impact": {}
    }

    risks = [0.0025, 0.0050, 0.0075, 0.0100]

    # 1. Regime Moderno FTMO (Orizzonte Illimitato, max_days=None)
    print("\n--- 1. Regime Moderno Prop Firm (Orizzonte Illimitato, No Time Limit) ---")
    for r in risks:
        res = run_full_challenge_v3_3(SEED, scen_iid, r, trades_per_day=2, max_days_per_phase=None, n_simulations=N_SIMS)
        res.pop("_challenge_outcomes", None)
        results["modern_unlimited_days"][f"{r:.4f}"] = res
        p = res["pass"]["rate"]
        ml = res["max_loss"]["rate"]
        dl = res["daily_loss"]["rate"]
        med_days = res["median_days_pass"]
        print(f"Risk {r:.2%}: Pass={p:.2%}, ML={ml:.2%}, DL={dl:.2%}, Giorni Mediani Passaggio={med_days}")

    # 2. Regime Legacy (60 giorni per fase)
    print("\n--- 2. Regime Storico Legacy (Max 60 giorni per fase) ---")
    for r in risks:
        res = run_full_challenge_v3_3(SEED, scen_iid, r, trades_per_day=2, max_days_per_phase=60, n_simulations=N_SIMS)
        res.pop("_challenge_outcomes", None)
        results["legacy_fixed_days"][f"{r:.4f}"] = res
        p = res["pass"]["rate"]
        to = res["timeout"]["rate"]
        print(f"Risk {r:.2%}: Pass={p:.2%}, Timeout={to:.2%}")

    # 3. Test Impatto MAE Browniano Accoppiato CRN Invariante su Intraday 1% (25 giorni)
    print("\n--- 3. Confronto Accoppiato CRN Invariante: Impatto MAE Browniano su Intraday 1% (25 giorni) ---")
    res_base_intra = run_full_challenge_v3_3(SEED, scen_iid, 0.01, trades_per_day=6, max_days_per_phase=25, n_simulations=N_SIMS)
    res_mae_intra = run_full_challenge_v3_3(SEED, scen_mae, 0.01, trades_per_day=6, max_days_per_phase=25, n_simulations=N_SIMS)

    outcomes_b = res_base_intra.pop("_challenge_outcomes", [])
    outcomes_m = res_mae_intra.pop("_challenge_outcomes", [])

    # Verifica rigida invarianza CRN
    pass_only_mae = sum(1 for i in range(N_SIMS) if outcomes_m[i] == "pass" and outcomes_b[i] != "pass")
    delta_pass = res_mae_intra["pass"]["rate"] - res_base_intra["pass"]["rate"]
    delta_dl = res_mae_intra["daily_loss"]["rate"] - res_base_intra["daily_loss"]["rate"]
    delta_ml = res_mae_intra["max_loss"]["rate"] - res_base_intra["max_loss"]["rate"]

    results["paired_crn_mae_impact"] = {
        "base_intraday_1pct": res_base_intra,
        "mae_intraday_1pct": res_mae_intra,
        "delta_pass_pct_points": round(delta_pass * 100, 2),
        "delta_daily_loss_pct_points": round(delta_dl * 100, 2),
        "delta_max_loss_pct_points": round(delta_ml * 100, 2),
        "impossible_passes_count": pass_only_mae
    }
    print(f"Base Intraday 1%: Pass={res_base_intra['pass']['rate']:.2%}, DL={res_base_intra['daily_loss']['rate']:.2%}, ML={res_base_intra['max_loss']['rate']:.2%}")
    print(f"Con MAE Browniano: Pass={res_mae_intra['pass']['rate']:.2%}, DL={res_mae_intra['daily_loss']['rate']:.2%}, ML={res_mae_intra['max_loss']['rate']:.2%}")
    print(f"Delta Effettivo MAE: Pass={delta_pass:+.2%}, Daily Loss={delta_dl:+.2%}, Max Loss={delta_ml:+.2%}")
    print(f"Controllo Invarianza CRN: Sfide passate SOLO con MAE = {pass_only_mae} (deve essere 0)")

    # 4. Confronto Accoppiato CRN: Impatto Slippage Pareto su Swing 1% (60 giorni)
    print("\n--- 4. Confronto Accoppiato CRN: Impatto Slippage Pareto su Swing 1% ---")
    res_base_swing = run_full_challenge_v3_3(SEED, scen_iid, 0.01, trades_per_day=2, max_days_per_phase=60, n_simulations=N_SIMS)
    res_slip_swing = run_full_challenge_v3_3(SEED, scen_slip, 0.01, trades_per_day=2, max_days_per_phase=60, n_simulations=N_SIMS)
    res_base_swing.pop("_challenge_outcomes", None)
    res_slip_swing.pop("_challenge_outcomes", None)

    delta_slip = res_slip_swing["pass"]["rate"] - res_base_swing["pass"]["rate"]
    results["paired_crn_slippage_impact"] = {
        "base_swing_1pct": res_base_swing,
        "slip_swing_1pct": res_slip_swing,
        "delta_pass_pct_points": round(delta_slip * 100, 2)
    }
    print(f"Base Swing 1%: Pass={res_base_swing['pass']['rate']:.2%}, ML={res_base_swing['max_loss']['rate']:.2%}")
    print(f"Con Slippage Pareto: Pass={res_slip_swing['pass']['rate']:.2%}, ML={res_slip_swing['max_loss']['rate']:.2%}")
    print(f"Delta Slippage: {delta_slip:+.2%}")

    # 5. Impatto Clustering Markov Stazionario P(L|L)=0.80 su Swing 1%
    print("\n--- 5. Impatto Clustering Markov Stazionario P(L|L)=0.80 su Swing 1% ---")
    res_markov = run_full_challenge_v3_3(SEED, scen_markov, 0.01, trades_per_day=2, max_days_per_phase=60, n_simulations=N_SIMS)
    res_markov.pop("_challenge_outcomes", None)
    delta_markov = res_markov["pass"]["rate"] - res_base_swing["pass"]["rate"]
    results["markov_clustering_impact"] = {
        "markov_swing_1pct": res_markov,
        "delta_pass_pct_points": round(delta_markov * 100, 2)
    }
    print(f"Markov P(L|L)=0.80: Pass={res_markov['pass']['rate']:.2%}, ML={res_markov['max_loss']['rate']:.2%}")
    print(f"Delta vs i.i.d.: {delta_markov:+.2%}")

    out_file = os.path.join(os.path.dirname(__file__), "simulations_v3_3_raw.json")
    with open(out_file, "w") as f:
        json.dump(results, f, indent=2)
    print(f"\n[OK] Risultati grezzi V3.3 esportati con successo in: {out_file}")


if __name__ == "__main__":
    main()
