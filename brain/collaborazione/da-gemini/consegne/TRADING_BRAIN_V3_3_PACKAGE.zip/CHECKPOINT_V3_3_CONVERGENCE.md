# CHECKPOINT V3.3: CONSOLIDAMENTO TECNICO SULLE RISERVE CLAUDE V3.2

**Data:** 12 Novembre 2026  
**Autore:** Gemini Antigravity (Quantitative Research Lab)  
**Destinatari:** Gioele Melis & Claude Code  
**Oggetto:** Rilascio ufficiale della Versione 3.3 Consolidata del Trading Brain.  
**Stato della Versione:**  
> **"V3.3 — PRONTA PER REVISIONE INDIPENDENTE."**

---

## 1. Stato dei Pacchetti e Conservazione delle Versioni Precedenti
- **Versione V2:** Congelata e intatta in `consegne/` (`MANIFEST_SHA256.txt` 100% OK).
- **Versione V3:** Congelata e intatta in `consegne-v3/` (`MANIFEST_SHA256_V3.txt` 100% OK).
- **Versione V3.1:** Congelata e intatta in `consegne-v3.1/` (`MANIFEST_SHA256_V3_1.txt` 100% OK).
- **Versione V3.2:** Congelata e intatta in `consegne-v3.2/` (`MANIFEST_SHA256_V3_2.txt` 100% OK, ZIP `989dd288...3d18`).
- **Versione V3.3:** Nuova versione consolidata indipendente rilasciata in `consegne-v3.3/`.

Nessun file precedente o storico è stato alterato o sovrascritto.

---

## 2. Sintesi delle Risoluzioni Tecniche Implementate (S-01..S-09)

1. **S-01 (Benchmark Fase 2 Esatto sul Reticolo):** Sostituito il riferimento simulato $0,8596$ con il valore analitico esatto del reticolo razionale **$0,8572$** (e $0,7800$ per la Fase 1, prodotto $0,6686$).
2. **S-02 (Uccisione Determinata dei Mutanti V10, V03, V07):** Inserito test MAE profondo con pavimento $7,5\%$ ($P = 1/14 \approx 0,0714$) che uccide V10 e V03. Il test a due fasi attraversa `run_full_challenge_v3_3`, uccidendo V07.
3. **S-03 (Correzione `LEGGIMI_V1.md`):** Rettificato import storico e sostituito `r.main()` con `r.run_suite()`. Entrambe le modalità A e B riproducono l'hash certificato `a6781b7e...`.
4. **S-04 (Quantili Esatti Wilson e Kelly):** Calcolo esatto tramite `statistics.NormalDist().inv_cdf` per qualsiasi livello di confidenza in $(0, 1)$. Eliminata ogni approssimazione a due livelli o di Hastings.
5. **S-05 (Guardie Asimmetriche Anti-Overflow MAE):** Riconosciuto l'underflow pulito a 0 dei termini con esponente negativo. Configurazione $WR=0,99, RR=500$ calcolabile ed esatta ($|P_{\text{win}} - 0,99| < 10^{-12}$).
6. **S-06 (Validazione Sistematica degli Input):** Rifiuto perentorio con `ValueError` per `nan`, `inf`, valori negativi non consentiti, $\alpha \le 0$, $\text{scale} \le 0$, $\text{cap} \le 0$, $\text{max\_days} < \text{min\_days}$.
7. **S-07 (Espansione Test Quantitativi su Slippage, Wilson, Soglia MAE):** Aggiunti test deterministici di slippage (uccisi V19 e V20), verifica momenti teorici in forma chiusa ($E[\min(S,c)] = 0,060169R$), Wilson noti (ucciso V21) e soglia $\mu = 2\cdot 10^{-7}$ (ucciso V22).
8. **S-08 (Rettifiche Documentali):** Dimensione ZIP V3.2 rettificata a 47.977 byte, commit revisione V3.1 corretto in `9ff4514`, max $|z| = 1,67$ per Gruppo A, precisata natura epistemica dei calcoli.
9. **S-09 (Quattro Ipotesi del Modello Stilizzato):** Formalizzate nei documenti e nel JSON le 4 assunzioni: overnight settlement, trade sequenziali, Markov re-init per-fase, target lock a rischio zero.

---

## 3. Comandi di Esecuzione e Verifica

```bash
cd brain/collaborazione/da-gemini/consegne-v3.3

# 1. Verifica crittografica integrale del pacchetto
shasum -a 256 -c MANIFEST_SHA256_V3_3.txt

# 2. Esecuzione suite di test completa (20/20 test OK)
python3 test_prop_risk_v3_3.py

# 3. Esecuzione runner simulazioni Monte Carlo
python3 run_simulations_v3_3.py
```
