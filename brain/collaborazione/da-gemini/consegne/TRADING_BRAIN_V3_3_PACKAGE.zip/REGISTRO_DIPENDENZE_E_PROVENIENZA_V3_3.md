# REGISTRO DELLE DIPENDENZE E PROVENIENZA DEI MATERIALI (V3.3)

**Data:** 12 Novembre 2026  
**Autore:** Gemini Antigravity (Quantitative Research Lab)  
**Riferimento:** Riserve S-01..S-09 (`CLAUDE_CORRECTION_PROPOSALS_V3_2.md`) e Mandato Ufficiale V3.3

---

## 1. Materiali di Archivio Storico Inclusi nel Pacchetto (`archivio_storico/`)

In piena conformità con i requisiti di verificabilità storica e tracciabilità quantitativa, tutti i documenti storici originali sono archiviati intatti nella cartella `archivio_storico/`:

1. **`prop_risk_engine_v1.py`** (SHA-256 originale preservato: `4436f3214d86d3ebdd9b8d29d18ac155a04c9d4247b21b6d508ae091a0825a1d`)
   - *Origine:* `TRADING_RESEARCH_LAB/02_Quantitative_Lab/prop_risk_engine.py`
   - *Descrizione:* Motore originale Monte Carlo (Studio 01) contenente il vincolo storico `day >= min_days` a monte del target.
2. **`run_comprehensive_simulations_v1.py`** (SHA-256 originale preservato: `7fde4c3ee1b60c9c8f167d5a82989602439ff069f7af08345cc9433cc16c4f4a`)
   - *Origine:* `TRADING_RESEARCH_LAB/02_Quantitative_Lab/run_comprehensive_simulations.py`
   - *Descrizione:* Runner di simulazione originale della V1 (importa `from prop_risk_engine import PropSimulationScenario, run_full_challenge_experiment, wilson_confidence_interval`).
3. **`prop_simulations_raw_v1.json`** (SHA-256 originale preservato: `a6781b7ea00bf772c11688f0396fbe68ceb8d8d7dc5692022ecc321e326cc081`)
   - *Origine:* `TRADING_RESEARCH_LAB/02_Quantitative_Lab/prop_simulations_raw.json`
   - *Descrizione:* Risultati grezzi storici della V1 (riproducibili byte per byte).
4. **`rulebook.yaml`** (SHA-256 originale preservato: `b1bcd2f9a98efa939e455420de5be2e474def275c7943016ea3b701a3dacebaa`)
   - *Origine:* `trading_brain/70_Risk_Guardian/rulebook.yaml`
   - *Descrizione:* Regole operative originarie del Trading Guardian.
5. **`STR_001_TSMOM_TREND_FOLLOWING.md`** (SHA-256 originale preservato: `603befe2b93689c88ce074503a5d8b1ba38c4a79e4b8ab26e8bad11d83931f52`)
   - *Origine:* `TRADING_RESEARCH_LAB/04_Autonomous_Proposals/STR_001_TSMOM_TREND_FOLLOWING.md`
   - *Descrizione:* Scheda originaria del Trend Following su canali Donchian.
6. **`STR_002_SP500_OPENING_GAP.md`** (SHA-256 originale preservato: `5fd5cac4f4385e70e9f7857401df0e8e2fc5643eaba5cfb938b4fe9443863230`)
   - *Origine:* `TRADING_RESEARCH_LAB/04_Autonomous_Proposals/STR_002_SP500_OPENING_GAP.md`
   - *Descrizione:* Scheda originaria dell'ipotesi Opening Gap S&P 500.
7. **`LEGGIMI_V1.md`** (Risoluzione S-03)
   - *Descrizione:* Guida tecnica corretta che riporta l'istruzione esatta di import del runner storico, la chiamata a `r.run_suite()` per la Modalità B e la raccomandazione di eseguire le verifiche in una directory temporanea isolata per non sovrascrivere l'archivio.

---

## 2. Dichiarazione di Perimetro: Questioni Rinviate (Q-07 e Q-09)

In conformità alle direttive tassative dell'**Incarico Ufficiale**:
- **Q-07 (Revisione Schede STR-001 e STR-002):** Esclusa da questa versione. La revisione delle schede operative (con esplicita dichiarazione dei periodi fuori campione già osservati sul mercato e con corretta modellazione degli ordini stop) è formalmente rinviata alla fase successiva di sviluppo strategico congiunto.
- **Q-09 (Ristrutturazione del Rulebook del Trading Guardian):** Esclusa da questa versione. La separazione strutturale tra vincoli normativi della prop firm (con fonti e date verificate) e regole interne di gestione del rischio (buffer soggettivi, GATE_03) attende le decisioni architetturali dell'utente sul Trading Guardian.

---

## 3. Dichiarazione di Governance: Master Mission (§0–§25)

- **Stato del file nel Brain:** Il file fisico della *Master Mission* non è presente nel repository locale o nel Brain.
- **Integrità documentale:** Conformemente alla regola di non alterazione e non fabbricazione di testi mancanti, la Master Mission non è stata ricostruita artificialmente. Il conferimento del testo originario resta affidato all'utente Gioele Melis.
