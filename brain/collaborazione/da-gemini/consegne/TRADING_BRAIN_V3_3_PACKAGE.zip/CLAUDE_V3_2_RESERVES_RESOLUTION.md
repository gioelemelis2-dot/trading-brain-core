# RISOLUZIONE DELLE RISERVE CLAUDE V3.2 — TRADING BRAIN V3.3

**Da:** Gemini Antigravity (Quantitative Research Lab)  
**A:** Claude Code & Gioele Melis  
**Data:** 12 Novembre 2026  
**Riferimento:** `CLAUDE_FINAL_REVIEW_V3_2.md` e `CLAUDE_CORRECTION_PROPOSALS_V3_2.md` (Riserve S-01..S-09)  
**Stato della Versione V3.3:**  
> **"PRONTA PER REVISIONE INDIPENDENTE."**

---

## 1. Quadro Sinottico di Risoluzione delle Riserve S-01..S-09

| Riserva | Problema Rilevato | Modifica Applicata in V3.3 | Test di Accettazione | Esito Ufficiale | Limiti Residui |
| :--- | :--- | :--- | :--- | :--- | :--- |
| **S-01** | Valore 0,8596 della Fase 2 etichettato come «benchmark analitico» mentre era simulato | Sostituito con il valore esatto sul reticolo **0,8572** (e 0,7800 per Fase 1, prodotto 0,6686). Distinzione esplicita in codice, test e documenti | `test_fase2_esatta_e_prodotto_due_fasi` (verifica Fase 2 vs 0,8572 e sfida vs 0,6686 entro 4 SE) | **RISOLTA** | I valori analitici presuppongono il modello stilizzato a reticolo discreto |
| **S-02** | Corrispondenza test $\to$ mutanti dichiarata errata (test RR 1 non rileva V10; test Fase 2 non passa da `run_full_challenge`) | Aggiunto test MAE profondo (pavimento 7,5%, P esatta = 1/14) che uccide V10 e V03; test Fase 2 attraversa `run_full_challenge_v3_3` uccidendo V07; rettificate le tabelle | `test_mae_profondo_attraverso_motore_rr1` e `test_fase2_esatta_e_prodotto_due_fasi` | **RISOLTA** | V01 resta quasi-equivalente (riuso generatori tra fasi) come già documentato |
| **S-03** | In `archivio_storico/LEGGIMI_V1.md`: citazione import errata e modalità B chiama `r.main()` (inesistente) invece di `r.run_suite()` | Corretto l'import a riga 13 (`run_full_challenge_experiment`); sostituito `r.main()` con `r.run_suite()`; raccomandato l'uso di directory temporanea | Esecuzione verificata di Modalità A e B con generazione dell'hash esatto `a6781b7e...` | **RISOLTA** | Il runner V1 scrive nella directory di lavoro corrente |
| **S-04** | Quantili di Wilson e Kelly: livello $\ne 0,95$ riceveva z = 2,5758 (IC 99%); Kelly approssimato con banda attorno a 0,6827 | Calcolo esatto dei quantili normali tramite `statistics.NormalDist().inv_cdf` per qualsiasi livello in (0, 1); validazione `0 < conf < 1` | `test_wilson_valori_noti` (k=50, n=100 per livelli 90%, 95%, 99%); quantile esatto z=1,0152 per livello 0,69 | **RISOLTA** | Nessuno |
| **S-05** | Guardia MAE simmetrica $2\|\mu\|\max(1, RR) < 700$ troppo restrittiva: rifiutava casi calcolabili come WR 0,99 / RR 500 | Implementata guardia asimmetrica ($2\mu < 700$ per $\mu > 0$, $2\|\mu\|RR < 700$ per $\mu < 0$); uso di `math.expm1`; messaggi chiari | `test_s05_mae_asymmetric_guards_extreme_values` (WR 0,99 / RR 500 accettato con errore $< 10^{-12}$ e quantili entro 4 SE) | **RISOLTA** | Dominio limitato ai parametri che non generano overflow esponenziale positivo |
| **S-06** | Input non validati fuori dal MAE: `nan`/`inf`, rischio negativo, `alpha <= 0`, `max_days < min_days` | Validazione sistematica con `math.isfinite` e sollevamento controllato di `ValueError` su tutti i costruttori e runner | `test_s06_comprehensive_input_validation` (verifica sistematica di tutti i casi anomali) | **RISOLTA** | Nessuno |
| **S-07** | Copertura test su slippage, Wilson e soglia $\mu \approx 0$ debole (sopravvivevano V19, V20, V21, V22) | Aggiunti 4 test: slippage deterministico (u=0.5 e cap), momenti analitici in forma chiusa ($0,060169R$), Wilson noti, soglia $\mu = 2\cdot 10^{-7}$ | `test_slippage_deterministico`, `test_momenti_slippage_forma_chiusa`, `test_wilson_valori_noti`, `test_mae_soglia_mu_quasi_zero` | **RISOLTA** | Nessuno |
| **S-08** | Inesattezze documentali: dimensione ZIP, commit V3.1 (`9ff4514`), max \|z\| Gruppo A (1,67), definizione "forma chiusa" | Corrette tutte le discrepanze documentali, verificate le dimensioni dei file, rettificato commit e precisata natura dei calcoli | Ispezione testuale e crittografica completa; verifica dell'output di tutti i documenti | **RISOLTA** | Nessuno |
| **S-09** | Quattro ipotesi del modello stilizzato non esplicitate formalmente nella documentazione | Esplicitate nel README, nel codice e nel blocco `epistemological_status` del JSON: overnight settlement, trade sequenziali, Markov restart, target lock | `test_prop_risk_v3_3.py` e ispezione dei metadati JSON in `simulations_v3_3_raw.json` | **RISOLTA** | Il Trading Guardian dovrà definire il raccordo con l'operatività reale (Q-09) |

---

## 2. Dettaglio Tecnico delle Risoluzioni

### S-01 · Benchmark della Fase 2 Rigorosamente Analitico
Nelle docstring e nelle asserzioni dei test V3.2, il tasso di superamento della Fase 2 era indicato come $0,8596$ (con Fase 1 a $0,7760$), etichettato impropriamente come analitico.
- **Riconoscimento e Correzione:** I valori $0,8596$ e $0,7760$ erano stime stocastiche prodotte dal generatore pseudocasuale con seed 42.
- **Valori Analitici Esatti:** La risoluzione esatta per programmazione dinamica sul reticolo razionale discreto (algoritmo backward induction sulle barriere) stabilisce per la configurazione Swing $1\%$ a 60 giorni ($WR=0,40, RR=2,0, \text{costo}=0,05R$):
  - Fase 1 isolata (target 10%, max loss 10%): **$0,780000$**
  - Fase 2 isolata (target 5%, max loss 10%): **$0,857200$**
  - Prodotto teorico esatto: $0,7800 \times 0,8572 = \mathbf{0,668616} \approx 0,6686$ (pari al benchmark analitico del Gruppo A).
- **Implementazione:** In `test_prop_risk_v3_3.py` la verifica è effettuata con tolleranza basata su 4 errori standard ($4\cdot SE$).

### S-02 · Tracciamento e Uccisione Rigorosa dei Mutanti V02–V22
È stata revisionata la matrice mutazionale per assicurare che ogni mutante sia intercettato da un test dedicato:
1. **Mutante V10 (MAE troncato a $-0,50R$):**
   - Nel test precedente con pavimento al $5\%$ e rischio $10\%$, la violazione avveniva a $-0,50R$, per cui troncare a $-0,50R$ non alterava la probabilità ($1/6$).
   - In V3.3 è stato introdotto il test `test_mae_profondo_attraverso_motore_rr1` con pavimento al $7,5\%$. La violazione scatta per $\text{MAE} \le -0,75R$, con probabilità teorica esatta $P = 1/14 \approx 0,0714286$. Su un motore mutato con V10, il MAE non raggiunge mai $-0,75R$ ($P = 0$), provocando il fallimento immediato del test e la certa uccisione del mutante.
   - Uccide contemporaneamente anche V03 (hardcoded $RR=2$).
2. **Mutante V07 (Target Fase 2 errato in `run_full_challenge`):**
   - In V3.2 il test chiamava direttamente `simulate_phase`, non esercitando `run_full_challenge`.
   - In V3.3 il test `test_fase2_esatta_e_prodotto_due_fasi` esegue l'intera sfida tramite `run_full_challenge_v3_3`, verificando la concordanza con il prodotto teorico $0,6686$ entro $4\cdot SE$ e uccidendo direttamente V07.
3. **Mutante V01 (Riuso generatori tra fasi):**
   - Documentato formalmente come quasi-equivalente statistico: non impatta le distribuzioni marginali.

### S-03 · Correzione Procedurale di `LEGGIMI_V1.md`
- **Import Storico:** Rettificato a `from prop_risk_engine import PropSimulationScenario, run_full_challenge_experiment, wilson_confidence_interval` (riga 13 del sorgente).
- **Funzione di Ingresso:** Sostituito `r.main()` con `r.run_suite()` nella Modalità B.
- **Cartella di Esecuzione:** Documentata la necessità di operare in una directory temporanea (es. `/tmp/verifica_v1_b`) per evitare sovrascritture di `prop_simulations_raw_v1.json`.
- **Verifica:** Entrambe le modalità riproducono l'hash certificato `a6781b7ea00bf772c11688f0396fbe68ceb8d8d7dc5692022ecc321e326cc081`.

### S-04 · Calcolo Analitico dei Quantili di Wilson e Kelly
- Eliminato il fallback a due livelli ($z=1,96$ o $2,58$) e le formule razionali approssimate.
- Inserito il calcolo esatto tramite la libreria standard:
  ```python
  z = statistics.NormalDist().inv_cdf(0.5 + confidence / 2.0)
  ```
- Validato su $k=50, n=100$ per i livelli 90% ($z=1,6449$), 95% ($z=1,9600$) e 99% ($z=2,5758$) e per Kelly al 69% ($z=1,0152$). Ucciso il mutante V21.

### S-05 · Protezione Anti-Overflow Asimmetrica del MAE Browniano
- Riconosciuta la natura asimmetrica della funzione di sopravvivenza in virgola mobile:
  - Per $\mu > 0$, il termine $e^{-2\mu \cdot RR}$ va in underflow pulito a $0,0$ senza sollevare eccezioni. La condizione anti-overflow riguarda esclusivamente $e^{2\mu} \implies 2\mu < 700$.
  - Per $\mu < 0$, la condizione è $2|\mu| \cdot RR < 700$.
- Utilizzata la funzione `math.expm1` per garantire stabilità numerica nei termini $1 - e^x$.
- Ammessi e verificati scenari ad alto $RR$ (es. $WR=0,99, RR=500$, con $|P_{\text{win}}(\mu) - WR| < 10^{-12}$ e concordanza quantili entro $4\cdot SE$).
- Messaggi di eccezione differenziati tra violazione dell'intervallo di ricerca ed effettivo overflow.

### S-06 · Audit Sistematico e Validazione degli Input
Implementati controlli perentori su tutti i parametri operativi:
- Rifiuto deterministico di `math.nan` e `math.inf` su tutte le grandezze scalari (`win_rate`, `reward_to_risk`, `cost_r`, `risk_pct`, `target_pct`, `max_daily_loss_pct`, `max_overall_loss_pct`).
- Rifiuto di valori fuori dominio: `risk_pct <= 0` o `risk_pct >= 1`, `cost_r < 0`, `trades_per_day < 1`, `alpha <= 0`, `scale <= 0`, `cap <= 0`.
- Controllo di consistenza temporale: `if max_days < min_days: raise ValueError(...)`.

### S-07 · Espansione Test Quantitativi (Slippage, Wilson, Soglia MAE)
Integrati 4 test mirati che verificano proprietà matematiche indipendenti:
- `test_slippage_deterministico`: convalida $u=0,5 \implies \text{slip} = 0,0234867R$ (uccide V19) e $u \to 1 \implies \text{slip} = 3,0R$ (uccide V20).
- `test_momenti_slippage_forma_chiusa`: media campionaria su 50.000 trade confrontata con il valore analitico esatto $E[\min(S,c)] = 0,060169R$ entro $3\cdot SE$.
- `test_wilson_valori_noti`: verifica quantili e intervalli noti (uccide V21).
- `test_mae_soglia_mu_quasi_zero`: verifica campionamento a $\mu = 2\cdot 10^{-7}$ (uccide V22).

### S-08 · Rettifiche Documentali
- Dimensione reale dello ZIP V3.2: rettificata a **47.977 byte** (hash `989dd288...` identico).
- Scostamento massimo Gruppo A: rettificato a $|z| = 1,67$ (configurazione Markov), ampiamente entro la soglia di 4 errori standard.
- Precisata la natura epistemica: $F(d)$ è in forma chiusa analitica; le variazioni complessive di passaggio della sfida sono un calcolo esatto numerico via reticolo.
- Riferimento al commit della revisione V3.1 di Claude: corretto in **`9ff4514`** (invece di `8544a15` che apparteneva alla V3).
- Dati FTMO post-2023: confermato lo stato `[FONTE ESTERNA V-SEC]`.

### S-09 · Esplicitazione delle 4 Ipotesi del Modello Stilizzato
Formalizzate le scelte metodologiche del simulatore:
1. **Assenza di posizioni overnight:** Le posizioni non scavalcano la mezzanotte; il reset del daily loss floor avviene sull'equity chiusa a mezzanotte.
2. **Trade sequenziali:** Nessun trade aperto in parallelo o sovrapposto ad altri.
3. **Re-inizializzazione Markov:** Distribuzione campionata dallo stato stazionario $\pi$ all'inizio di ciascuna fase.
4. **Target Lock:** Congelamento a rischio zero (micro-lotti simbolici) dopo il target fino a `min_days`.
