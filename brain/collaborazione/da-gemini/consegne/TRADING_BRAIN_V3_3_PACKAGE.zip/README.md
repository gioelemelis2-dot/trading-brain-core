# PACCHETTO DI CONSEGNA V3.3 CONSOLIDATA (TRADING BRAIN)

**Autore:** Gemini Antigravity (Quantitative Research Lab)  
**Audit Avversariale e Revisione Indipendente:** Claude Code  
**Data:** 12 Novembre 2026  
**Riferimento:** `CLAUDE_FINAL_REVIEW_V3_2.md` e `CLAUDE_CORRECTION_PROPOSALS_V3_2.md` (Riserve S-01..S-09)  
**Stato Ufficiale della Versione:**  
> **"V3.3 — PRONTA PER REVISIONE INDIPENDENTE."**

---

## Ordine di Lettura Consigliato per la Revisione Indipendente

1. **`CHECKPOINT_V3_3_CONVERGENCE.md`**  
   Sintesi esecutiva delle risoluzioni applicate alle 9 riserve di Claude (S-01..S-09), esiti dei test e stato del versionamento.

2. **`CLAUDE_V3_2_RESERVES_RESOLUTION.md`**  
   Rapporto dettagliato con tabella sinottica per ciascuna riserva S-01..S-09 (Problema, Modifica, Test, Esito ufficiale, Limiti residui).

3. **`V3_3_CHANGELOG.md`**  
   Tracciamento analitico di ogni modifica apportata a codice, test, runner, metadati e documentazione.

4. **`V3_3_MATHEMATICAL_VERIFICATION.md`**  
   Dimostrazioni e verifiche matematiche indipendenti: benchmark sul reticolo a due fasi ($0,7800 \times 0,8572 = 0,6686$), momenti analitici dello slippage Lomax troncato ($E[\min(S,c)] = 0,060169R$), MAE profondo ($P = 1/14$), quantili NormalDist esatti e limiti anti-overflow asimmetrici.

5. **`V3_3_TEST_REPORT.md`**  
   Report completo di collaudo: 20 test unitari su 20 superati; neutralizzazione del 100% dei 21 mutanti non-equivalenti (V02–V22); analisi del mutante quasi-equivalente V01.

6. **`prop_risk_engine_v3_3.py`**  
   Codice sorgente del motore consolidato: NormalDist esatta per Wilson e Kelly, guardie asimmetriche anti-overflow, validazione sistematica degli input fuori dal MAE e formalizzazione delle 4 ipotesi stilizzate.

7. **`test_prop_risk_v3_3.py`**  
   Suite di 20 test unitari, analitici e mutazionali eseguibile con pura libreria standard di Python (`python3 test_prop_risk_v3_3.py`).

8. **`run_simulations_v3_3.py`** e **`simulations_v3_3_raw.json`**  
   Runner Monte Carlo con percorsi accoppiati (CRN invariante) e dataset grezzo con metadati epistemologici arricchiti.

9. **`REGISTRO_DIPENDENZE_E_PROVENIENZA_V3_3.md`** e cartella **`archivio_storico/`**  
   Materiali storici originali e `LEGGIMI_V1.md` corretto (risoluzione S-03).

10. **`MANIFEST_SHA256_V3_3.txt`** (e `V3_3_MANIFEST.sha256`)  
    Manifest crittografico completo che copre e certifica ogni singolo file del pacchetto.
