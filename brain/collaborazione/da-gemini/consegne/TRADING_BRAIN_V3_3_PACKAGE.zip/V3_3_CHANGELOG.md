# CHANGELOG V3.3 — TRADING BRAIN CONSOLIDATO

**Data di rilascio:** 12 Novembre 2026  
**Autore:** Gemini Antigravity (Quantitative Research Lab)  
**Versione precedente:** V3.2 (`TRADING_BRAIN_V3_2_PACKAGE.zip`, hash `989dd288...3d18`)  
**Stato:** Consolidamento correttivo basato su `CLAUDE_CORRECTION_PROPOSALS_V3_2.md`

---

## 1. Modifiche al Codice Sorgente del Motore (`prop_risk_engine_v3_3.py`)

- **Wilson Confidence Interval (`wilson_confidence_interval`):**
  - Sostituito il quantile binario ($1,96$ per $0,95$, altrimenti $2,58$) con il calcolo continuo esatto tramite `statistics.NormalDist().inv_cdf(0.5 + confidence / 2.0)` (S-04).
  - Aggiunta validazione rigorosa: sollevamento di `ValueError` se `confidence` non è finito o fuori dall'intervallo aperto $(0, 1)$ (S-04, S-06).
  - Validati parametri binomiali: $n \ge 0, 0 \le k \le n$.
- **Kelly Confidence Interval (`calculate_kelly_confidence_interval`):**
  - Sostituita l'approssimazione razionale di Hastings e la banda $\pm 0,01$ con il quantile esatto ricavato da `statistics.NormalDist` (S-04).
  - Validazione sistematica di tutti i parametri: `n_trades > 0` intero, `win_rate` in $(0, 1)$, `reward_to_risk > 0`, `cost_r >= 0`, `confidence_level` in $(0, 1)$ (S-06).
- **Risolutore della Deriva Browniana (`solve_brownian_drift_for_scenario`):**
  - Introdotta la guardia anti-overflow asimmetrica: per $\mu > 0$ controllo $2\mu < 700$ (essendo l'esponente negativo in underflow pulito a 0); per $\mu < 0$ controllo $2|\mu| \cdot RR < 700$ (S-05).
  - Utilizzata la funzione `math.expm1` per garantire la stabilità numerica ed eliminare la cancellazione catastrofica (S-05).
  - Ammesse e verificate configurazioni estreme ad alto $RR$ (es. $WR=0,99, RR=500$) con precisione $|P_{\text{win}}(\mu) - WR| < 10^{-12}$ (S-05).
  - Differenziati i messaggi di eccezione tra limiti dell'intervallo di bisezione ed effettivo overflow, formattando $WR$ con 8 cifre decimali (S-05).
- **Campionatore MAE Browniano (`sample_brownian_mae_given_win`):**
  - Riscritto il calcolo tramite `expm1` e gestione robusta dell'underflow di $e^{-2\mu b}$ per grandi valori di $b$ ($RR$) (S-05).
- **Costruttore dello Scenario (`PropSimulationScenarioV3_3`):**
  - Audit e validazione sistematica: controllo `math.isfinite` su tutti i parametri scalari; rifiuto di `nan`, `inf`, valori negativi non ammessi, $\alpha \le 0$, $\text{scale} \le 0$, $\text{cap} \le 0$ (S-06).
- **Simulatore di Fase (`simulate_phase_v3_3`):**
  - Controllo di coerenza temporale: sollevamento perentorio di `ValueError` se `max_days < min_days` (S-06).
  - Validazione di `risk_pct` in $(0, 1)$, `trades_per_day >= 1`, `target_pct > 0`, pavimenti $> 0$.
  - Formalizzate nei commenti le 4 ipotesi metodologiche stilizzate (overnight settlement, trade sequenziali, Markov re-init, target lock) (S-09).
- **Runner della Sfida (`run_full_challenge_v3_3`):**
  - Validati `n_simulations >= 1`, `fase1_target > 0`, `fase2_target > 0` (S-06).

---

## 2. Modifiche alla Suite di Test (`test_prop_risk_v3_3.py`)

- **Benchmark Esatto Fase 2 (S-01):**
  - Sostituito il riferimento simulato $0,8596$ con il valore analitico esatto del reticolo backward induction: **$0,8572$** (e $0,7800$ per la Fase 1, prodotto $0,6686$).
  - Tolleranza parametrata su 4 errori standard Monte Carlo ($4\cdot SE$).
- **Test MAE Profondo attraverso il Motore (S-02):**
  - Aggiunto `test_mae_profondo_attraverso_motore_rr1`: configurazione $RR=1,0, WR=0,50$, rischio $10\%$, pavimento $7,5\%$, violazione per $MAE \le -0,75R$. Frequenza esatta $P = 1/14 \approx 0,0714286$. Uccide direttamente V10 (dove $P=0$) e V03.
- **Test Due Fasi attraverso `run_full_challenge` (S-02):**
  - Aggiornato `test_fase2_esatta_e_prodotto_due_fasi`: esegue la sfida intera a due fasi verificando il benchmark $0,6686$ entro $4\cdot SE$, uccidendo direttamente V07.
- **Test Quantitativo Wilson su Valori Noti (S-04, S-07):**
  - Aggiunto `test_wilson_valori_noti`: verifica $k=50, n=100$ per i livelli 90% ($[0,4188, 0,5812]$), 95% ($[0,4038, 0,5962]$) e 99% ($[0,3753, 0,6247]$). Uccide V21.
- **Test Deterministico Slippage e Rispetto del Cap (S-07):**
  - Aggiunto `test_slippage_deterministico`: convalida formula per $u=0,5$ ($0,0234867R$, uccide V19) e rispetto del cap a $3,0R$ per $u \to 1$ (uccide V20).
- **Test Momenti Teorici Slippage in Forma Chiusa (S-07):**
  - Aggiunto `test_momenti_slippage_forma_chiusa`: media campionaria confrontata con $E[\min(S,c)] = 0,060169R$ entro $3\cdot SE$.
- **Test Soglia $\mu \approx 0$ del Campionatore (S-07):**
  - Aggiunto `test_mae_soglia_mu_quasi_zero`: verifica campionamento a $\mu = 2\cdot 10^{-7}$ con deriva attiva (uccide V22).
- **Test Guardie Asimmetriche MAE (S-05):**
  - Aggiunto `test_s05_mae_asymmetric_guards_extreme_values`: verifica scenario estremo calcolabile $WR=0,99, RR=500$ e concordanza quantili $F(d)$ entro $4\cdot SE$.
- **Test Completo Validazione Input (S-06):**
  - Aggiunto `test_s06_comprehensive_input_validation`: copertura sistematica di tutti i casi anomali (NaN, Inf, valori negativi, alpha zero, max_days < min_days).

---

## 3. Modifiche al Runner e ai Risultati Grezzi (`run_simulations_v3_3.py`)

- Versione aggiornata a `3.3.0`.
- Arricchito il blocco `epistemological_status` con:
  - Benchmark esatti della sfida a due fasi sul reticolo ($0,7800 \times 0,8572 = 0,6686$) (S-01);
  - Momenti teorici esatti dello slippage Lomax in forma chiusa ($0,060169R$) (S-07);
  - Le quattro ipotesi formali del modello stilizzato (overnight, sequenzialità, Markov re-init, target lock) (S-09);
  - Allineamento delle note su FTMO allo stato di fonte esterna V-SEC (S-08).

---

## 4. Modifiche all'Archivio Storico (`archivio_storico/LEGGIMI_V1.md`)

- Rettificato l'import storico citato: `from prop_risk_engine import PropSimulationScenario, run_full_challenge_experiment, wilson_confidence_interval` (S-03).
- Sostituita la chiamata `r.main()` con `r.run_suite()` nella Modalità B (S-03).
- Specificata la generazione di `prop_simulations_raw.json` nella cartella di lavoro corrente e raccomandato l'uso di una directory temporanea (S-03).
