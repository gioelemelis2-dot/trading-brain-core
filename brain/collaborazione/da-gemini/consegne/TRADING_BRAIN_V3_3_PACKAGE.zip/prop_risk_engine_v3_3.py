#!/usr/bin/env python3
"""
prop_risk_engine_v3_3.py
Trading Brain - Quantitative Risk & Prop Evaluation Engine (Versione 3.3 Consolidata)

Paternita e Governance:
- Sviluppo e test: Gemini Antigravity (Quantitative Research Lab)
- Audit avversariale e proposte di correzione: Claude Code
- Riferimento revisione V3.2: CLAUDE_FINAL_REVIEW_V3_2.md (esito: VALIDATA CON RISERVE S-01..S-09)

Risoluzione sistematica delle riserve S-01..S-09:
1. S-01: Distinzione rigorosa tra valori analitici esatti sul reticolo (Fase 1: 0.7800, Fase 2: 0.8572, Prodotto: 0.6686)
   e stime Monte Carlo simulate.
2. S-02: Corrispondenza test-mutanti documentata e verificata. Aggiunto test MAE profondo (pavimento 7.5%, P esatta = 1/14)
   che uccide direttamente V10 e V03.
3. S-04: Calcolo esatto dei quantili normali tramite statistics.NormalDist().inv_cdf per qualsiasi livello di confidenza
   in (0, 1), sia in wilson_confidence_interval che in calculate_kelly_confidence_interval (eliminata ogni approssimazione).
4. S-05: Protezione anti-overflow del MAE asimmetrica: 2*mu < 700 per mu > 0, e 2*|mu|*RR < 700 per mu < 0.
   Uso di math.expm1 per stabilita numerica. Gestione senza overflow di scenari estremi ammissibili (es. WR 0.99 / RR 500).
5. S-06: Validazione sistematica di tutti gli input: rifiuto di NaN, Inf, valori negativi, alpha <= 0, max_days < min_days.
6. S-07: Test quantitativi specifici su slippage deterministico, momenti teorici esatti (E[min(S,c)] = 0.060169R),
   intervalli di Wilson noti e soglia mu ~ 0.
7. S-08: Rettifica documentale completa (hash, dimensioni, commit, etichette epistemiche).
8. S-09: Esplicitazione formale delle quattro ipotesi del modello stilizzato:
   - Ipotesi 1 (Overnight): Nessuna posizione aperta a mezzanotte; pavimento calcolato su equity chiusa a mezzanotte.
   - Ipotesi 2 (Sequenzialita): Trade strettamente sequenziali, mai sovrapposti.
   - Ipotesi 3 (Markov): Re-inizializzazione stazionaria all'inizio di ciascuna fase.
   - Ipotesi 4 (Target Lock): Al raggiungimento del target, operativita simbolica a rischio zero fino a min_days.

Zero dipendenze esterne: pura libreria standard di Python.
"""

import math
import random
import statistics
from typing import Dict, Any, Tuple, List, Optional


def wilson_confidence_interval(k: int, n: int, confidence: float = 0.95) -> Tuple[float, float]:
    """
    Intervallo di confidenza Wilson per proporzioni binomiali (S-04).
    Calcolo esatto del quantile z per qualsiasi livello di confidenza in (0, 1) tramite statistics.NormalDist.
    """
    if not (math.isfinite(confidence) and 0.0 < confidence < 1.0):
        raise ValueError(f"confidence deve essere compreso tra 0 e 1 (esclusi), ricevuto: {confidence}")
    if n < 0 or k < 0 or k > n:
        raise ValueError(f"Parametri binomiali non validi: k={k}, n={n}")
    if n == 0:
        return 0.0, 0.0

    z = statistics.NormalDist().inv_cdf(0.5 + confidence / 2.0)
    p = k / n
    denom = 1.0 + (z**2) / n
    center = (p + (z**2) / (2.0 * n)) / denom
    half_width = (z * math.sqrt((p * (1.0 - p) / n) + ((z**2) / (4.0 * (n**2))))) / denom
    return max(0.0, center - half_width), min(1.0, center + half_width)


def calculate_kelly_confidence_interval(
    n_trades: int,
    win_rate: float,
    reward_to_risk: float,
    cost_r: float = 0.05,
    confidence_level: float = 0.95
) -> Tuple[float, float, float, float]:
    """
    Calcolo analitico dell'intervallo di confidenza per l'edge atteso E[R] (S-04, S-06).
    Usa il quantile esatto ricavato da statistics.NormalDist per qualsiasi livello in (0, 1).
    
    Restituisce:
    (expected_r, se_expected_r, ci_lower_r, ci_upper_r)
    """
    if not isinstance(n_trades, int) or n_trades <= 0:
        raise ValueError(f"n_trades deve essere intero > 0, ricevuto: {n_trades}")
    if not (math.isfinite(win_rate) and 0.0 < win_rate < 1.0):
        raise ValueError(f"win_rate deve essere compreso tra 0 e 1, ricevuto: {win_rate}")
    if not (math.isfinite(reward_to_risk) and reward_to_risk > 0.0):
        raise ValueError(f"reward_to_risk deve essere positivo e finito, ricevuto: {reward_to_risk}")
    if not (math.isfinite(cost_r) and cost_r >= 0.0):
        raise ValueError(f"cost_r deve essere non negativo e finito, ricevuto: {cost_r}")
    if not (math.isfinite(confidence_level) and 0.0 < confidence_level < 1.0):
        raise ValueError(f"confidence_level deve essere compreso tra 0 e 1, ricevuto: {confidence_level}")

    # Valore atteso per trade in unita R
    expected_r = (win_rate * reward_to_risk) - ((1.0 - win_rate) * 1.0) - cost_r

    # Errore standard della proporzione campionaria di vincita: SE[WR] = sqrt(WR * (1 - WR) / N)
    se_wr = math.sqrt(win_rate * (1.0 - win_rate) / n_trades)

    # SE[E[R]] = (RR + 1) * SE[WR]
    se_expected_r = (reward_to_risk + 1.0) * se_wr

    # Quantile z esatto da NormalDist (S-04)
    z = statistics.NormalDist().inv_cdf(0.5 + confidence_level / 2.0)

    half_width = z * se_expected_r
    ci_lower = expected_r - half_width
    ci_upper = expected_r + half_width

    return expected_r, se_expected_r, ci_lower, ci_upper


def solve_brownian_drift_for_scenario(win_rate: float, reward_to_risk: float) -> float:
    """
    Risolve la deriva mu per moto browniano continuo dX = mu dt + dW con barriere a -1 e +RR
    tale che P_win(mu) = win_rate (S-05).
    
    Protezione anti-overflow asimmetrica:
    - Per mu > 0: l'unico esponente positivo e 2*mu -> guardia 2*mu < 700.
      Il termine exp(-2*mu*RR) va in underflow pulito a 0.0 senza errori per RR grande.
    - Per mu < 0: l'unico esponente positivo e -2*mu*RR -> guardia 2*|mu|*RR < 700.
      Il termine exp(2*mu) va in underflow pulito a 0.0 senza errori.
    - Uso di math.expm1 per evitare cancellazione numerica.
    """
    if not (math.isfinite(win_rate) and 0.0 < win_rate < 1.0):
        raise ValueError(f"win_rate deve essere compreso tra 0 e 1, ricevuto: {win_rate}")
    if not (math.isfinite(reward_to_risk) and reward_to_risk > 0.0):
        raise ValueError(f"reward_to_risk deve essere positivo e finito, ricevuto: {reward_to_risk}")

    fair_wr = 1.0 / (1.0 + reward_to_risk)
    if abs(win_rate - fair_wr) < 1e-7:
        return 0.0

    def p_win(mu_val: float) -> float:
        if abs(mu_val) < 1e-7:
            return fair_wr
        if mu_val > 0.0:
            if 2.0 * mu_val >= 700.0:
                raise OverflowError(f"2*mu ({2.0 * mu_val:.2f}) >= 700")
            arg_neg = -2.0 * mu_val * reward_to_risk
            exp_neg = math.exp(arg_neg) if arg_neg > -700.0 else 0.0
            num = -math.expm1(2.0 * mu_val)
            den = exp_neg - math.exp(2.0 * mu_val)
            return num / den
        else:
            if -2.0 * mu_val * reward_to_risk >= 700.0:
                raise OverflowError(f"-2*mu*RR ({-2.0 * mu_val * reward_to_risk:.2f}) >= 700")
            arg_neg = 2.0 * mu_val
            exp_neg = math.exp(arg_neg) if arg_neg > -700.0 else 0.0
            num = 1.0 - exp_neg
            den = math.exp(-2.0 * mu_val * reward_to_risk) - exp_neg
            return num / den

    # Limiti asimmetrici di ricerca per bisezione (S-05)
    # Per mu > 0, il limite e 345.0 (per 2*mu < 690)
    # Per mu < 0, il limite e 690.0 / (2.0 * RR)
    max_mu_neg = 690.0 / (2.0 * max(1.0, reward_to_risk))
    low = -min(15.0, max_mu_neg)
    high = min(15.0, 345.0)

    try:
        val_low = p_win(low)
        val_high = p_win(high)
    except OverflowError as e:
        raise ValueError(
            f"Parametri MAE estremi generano overflow nei limiti di bisezione: WR={win_rate:.8f}, RR={reward_to_risk:.4f}. Dettaglio: {e}"
        )

    if win_rate < val_low or win_rate > val_high:
        raise ValueError(
            f"Configurazione MAE browniano non realizzabile nell'intervallo di ricerca: "
            f"WR={win_rate:.8f} non compreso in [{val_low:.8f}, {val_high:.8f}] "
            f"per RR={reward_to_risk:.4f}."
        )

    for _ in range(60):
        mid = (low + high) * 0.5
        val = p_win(mid)
        if val < win_rate:
            low = mid
        else:
            high = mid

    solved_mu = (low + high) * 0.5

    # Validazione di convergenza
    final_p = p_win(solved_mu)
    if abs(final_p - win_rate) >= 1e-7:
        raise ValueError(
            f"Il risolutore della deriva browniana non converge entro 1e-7: "
            f"target WR={win_rate:.8f}, ottenuto P_win={final_p:.8f}, scarto={abs(final_p - win_rate):.2e}"
        )

    return solved_mu


def sample_brownian_mae_given_win(rng: random.Random, reward_to_risk: float, mu: float) -> float:
    """
    Campionamento esatto del MAE intra-trade condizionato al raggiungimento del target (+reward_to_risk)
    prima dello stop loss (-1.0R) per moto browniano continuo con deriva mu e sigma=1 (S-05).
    Risoluzione analitica esatta in forma chiusa tramite inversione di probabilita (zero approssimazioni).
    Restituisce un valore -m in [-1.0, 0.0].
    """
    u = rng.random()
    u = max(1e-12, min(1.0 - 1e-12, u))

    a = 1.0
    b = reward_to_risk

    if abs(mu) < 1e-7:
        m = (a * b * (1.0 - u)) / (b + a * u)
    else:
        arg_b = -2.0 * mu * b
        arg_a = 2.0 * mu * a
        exp_neg_b = math.exp(arg_b) if arg_b > -700.0 else 0.0
        num_c1 = -math.expm1(arg_b)
        den_c1 = math.expm1(arg_a)
        c1 = num_c1 / den_c1
        term1 = num_c1 * (1.0 + 1.0 / den_c1)
        term2 = u * exp_neg_b
        y = (term1 + term2) / (u + c1)
        m = math.log(max(1e-15, y)) / (2.0 * mu)

    m = min(0.999, max(0.0, m))
    return -m


class PropSimulationScenarioV3_3:
    """Scenario di simulazione per challenge prop firm (Versione 3.3 Consolidata)."""
    def __init__(
        self,
        name: str,
        win_rate: float,
        reward_to_risk: float,
        cost_r: float = 0.05,
        p_loss_given_loss: Optional[float] = None,
        use_brownian_mae: bool = False,
        slippage_tail_alpha: Optional[float] = None,
        slippage_scale: float = 0.05,
        slippage_cap_r: float = 3.0
    ):
        # Validazione sistematica degli input (S-06)
        if not (math.isfinite(win_rate) and 0.0 < win_rate < 1.0):
            raise ValueError(f"win_rate deve essere compreso tra 0 e 1 (esclusi), ricevuto: {win_rate}")
        if not (math.isfinite(reward_to_risk) and reward_to_risk > 0.0):
            raise ValueError(f"reward_to_risk deve essere positivo e finito, ricevuto: {reward_to_risk}")
        if not (math.isfinite(cost_r) and cost_r >= 0.0):
            raise ValueError(f"cost_r deve essere non negativo e finito, ricevuto: {cost_r}")

        if slippage_tail_alpha is not None:
            if not (math.isfinite(slippage_tail_alpha) and slippage_tail_alpha > 0.0):
                raise ValueError(f"slippage_tail_alpha deve essere positivo e finito, ricevuto: {slippage_tail_alpha}")
        if not (math.isfinite(slippage_scale) and slippage_scale > 0.0):
            raise ValueError(f"slippage_scale deve essere positivo e finito, ricevuto: {slippage_scale}")
        if not (math.isfinite(slippage_cap_r) and slippage_cap_r > 0.0):
            raise ValueError(f"slippage_cap_r deve essere positivo e finito, ricevuto: {slippage_cap_r}")

        self.name = name
        self.win_rate = win_rate
        self.reward_to_risk = reward_to_risk
        self.cost_r = cost_r
        self.p_loss_given_loss = p_loss_given_loss
        self.use_brownian_mae = use_brownian_mae
        self.slippage_tail_alpha = slippage_tail_alpha
        self.slippage_scale = slippage_scale
        self.slippage_cap_r = slippage_cap_r

        # Validazione ammissibilita stazionaria Markov (C-02)
        if self.p_loss_given_loss is not None:
            if not (math.isfinite(self.p_loss_given_loss) and 0.0 <= self.p_loss_given_loss <= 1.0):
                raise ValueError(f"p_loss_given_loss deve essere in [0, 1], ricevuto: {self.p_loss_given_loss}")
            min_p_ll = 1.0 - (self.win_rate / (1.0 - self.win_rate))
            if self.p_loss_given_loss < min_p_ll - 1e-9:
                raise ValueError(
                    f"Parametro Markov non ammissibile: per win_rate={self.win_rate:.4f}, "
                    f"p_loss_given_loss deve essere >= {min_p_ll:.4f} per preservare la distribuzione stazionaria. "
                    f"Ricevuto: {self.p_loss_given_loss:.4f}"
                )
            p_loss_base = 1.0 - self.win_rate
            self.p_loss_given_win = (p_loss_base - self.p_loss_given_loss * p_loss_base) / self.win_rate
        else:
            self.p_loss_given_win = None

        # Pre-calcolo deriva mu e validazione parametri MAE (S-05)
        if self.use_brownian_mae:
            self.brownian_mu = solve_brownian_drift_for_scenario(self.win_rate, self.reward_to_risk)
        else:
            self.brownian_mu = 0.0

        self.gross_expectancy = (win_rate * reward_to_risk) - ((1.0 - win_rate) * 1.0)
        self.net_expectancy = self.gross_expectancy - cost_r


def simulate_phase_v3_3(
    rng_outcome: random.Random,
    rng_mae: random.Random,
    rng_slippage: random.Random,
    scenario: PropSimulationScenarioV3_3,
    risk_pct: float,
    trades_per_day: int,
    max_days: Optional[int],
    target_pct: float,
    max_daily_loss_pct: float = 0.05,
    max_overall_loss_pct: float = 0.10,
    min_days: int = 4
) -> Tuple[str, int, float]:
    """
    Simula una singola fase prop conforme alle specifiche V3.3.
    
    Validazione sistematica degli input (S-06):
    - risk_pct in (0, 1), trades_per_day >= 1, target_pct > 0, loss floors > 0.
    - min_days >= 1; se max_days non e None, max_days >= min_days (altrimenti ValueError).
    
    Assunzioni del modello stilizzato (S-09):
    1. Nessuna posizione aperta a mezzanotte (il pavimento daily loss usa l'equity chiusa a mezzanotte).
    2. Trade strettamente sequenziali (mai sovrapposti).
    3. Re-campionamento della catena di Markov dalla distribuzione stazionaria.
    4. Congelamento a rischio zero dopo il target fino a min_days.
    """
    if not (math.isfinite(risk_pct) and 0.0 < risk_pct < 1.0):
        raise ValueError(f"risk_pct deve essere in (0, 1), ricevuto: {risk_pct}")
    if not isinstance(trades_per_day, int) or trades_per_day < 1:
        raise ValueError(f"trades_per_day deve essere intero >= 1, ricevuto: {trades_per_day}")
    if not (math.isfinite(target_pct) and target_pct > 0.0):
        raise ValueError(f"target_pct deve essere positivo e finito, ricevuto: {target_pct}")
    if not (math.isfinite(max_daily_loss_pct) and max_daily_loss_pct > 0.0):
        raise ValueError(f"max_daily_loss_pct deve essere positivo e finito, ricevuto: {max_daily_loss_pct}")
    if not (math.isfinite(max_overall_loss_pct) and max_overall_loss_pct > 0.0):
        raise ValueError(f"max_overall_loss_pct deve essere positivo e finito, ricevuto: {max_overall_loss_pct}")
    if not isinstance(min_days, int) or min_days < 1:
        raise ValueError(f"min_days deve essere intero >= 1, ricevuto: {min_days}")

    if max_days is not None:
        if not isinstance(max_days, int) or max_days < 1:
            raise ValueError(f"max_days deve essere intero >= 1 o None, ricevuto: {max_days}")
        if max_days < min_days:
            raise ValueError(f"max_days ({max_days}) non puo essere inferiore a min_days ({min_days})")

    equity = 0.0
    target_locked = False
    target_hit_day = 0

    # Ipotesi 3: Inizializzazione catena Markov dalla distribuzione stazionaria pi (S-09)
    if scenario.p_loss_given_loss is not None:
        last_outcome_was_loss = (rng_outcome.random() >= scenario.win_rate)
    else:
        last_outcome_was_loss = False

    day = 1
    max_day_limit = max_days if max_days is not None else 100_000

    while day <= max_day_limit:
        # Ipotesi 1: midnight_equity registrata a mezzanotte a posizioni chiuse (S-09)
        midnight_equity = equity
        daily_loss_floor = midnight_equity - max_daily_loss_pct

        for _ in range(trades_per_day):
            if target_locked:
                # Ipotesi 4: micro-lotti a rischio zero per soddisfare min_days (S-09)
                continue

            # 1. Determinazione esito trade (W / L)
            if scenario.p_loss_given_loss is not None:
                if last_outcome_was_loss:
                    prob_loss = scenario.p_loss_given_loss
                else:
                    prob_loss = scenario.p_loss_given_win
                is_win = (rng_outcome.random() >= prob_loss)
            else:
                is_win = (rng_outcome.random() < scenario.win_rate)

            last_outcome_was_loss = not is_win

            # 2. Ipotesi 2: Verifica intra-trade MAE su posizioni sequenziali non sovrapposte (S-09)
            if is_win and scenario.use_brownian_mae:
                mae_draw = sample_brownian_mae_given_win(rng_mae, scenario.reward_to_risk, scenario.brownian_mu)
                floating_intra_equity = equity + (mae_draw * risk_pct)

                # Priorita uniforme: Rovina > Max Loss > Daily Loss
                if floating_intra_equity <= -1.0:
                    return ("absolute_ruin", day, floating_intra_equity)
                if floating_intra_equity <= -max_overall_loss_pct:
                    return ("max_loss", day, floating_intra_equity)
                if floating_intra_equity <= daily_loss_floor:
                    return ("daily_loss", day, floating_intra_equity)

            # 3. Calcolo PnL a posizione chiusa e Slippage
            if is_win:
                r_gross = scenario.reward_to_risk
            else:
                slip = 0.0
                if scenario.slippage_tail_alpha is not None:
                    u_slip = rng_slippage.random()
                    raw_slip = ((1.0 - u_slip) ** (-1.0 / scenario.slippage_tail_alpha) - 1.0) * scenario.slippage_scale
                    slip = min(scenario.slippage_cap_r, max(0.0, raw_slip))
                r_gross = -1.0 - slip

            r_net = r_gross - scenario.cost_r
            equity += r_net * risk_pct

            # 4. Controllo violazione barriere a chiusura posizione
            if equity <= -1.0:
                return ("absolute_ruin", day, equity)
            if equity <= -max_overall_loss_pct:
                return ("max_loss", day, equity)
            if equity <= daily_loss_floor:
                return ("daily_loss", day, equity)

            # 5. Raggiungimento Target
            if equity >= target_pct:
                target_locked = True
                target_hit_day = day

        # Controllo uscita al compimento dei giorni minimi
        if target_locked and day >= min_days:
            return ("pass", day, equity)

        day += 1

    if target_locked:
        return ("pass", max(min_days, target_hit_day), equity)

    return ("timeout", max_day_limit, equity)


def run_full_challenge_v3_3(
    seed: int,
    scenario: PropSimulationScenarioV3_3,
    risk_pct: float,
    trades_per_day: int,
    max_days_per_phase: Optional[int],
    n_simulations: int,
    fase1_target: float = 0.10,
    fase2_target: float = 0.05,
    max_daily_loss: float = 0.05,
    max_overall_loss: float = 0.10,
    min_days: int = 4
) -> Dict[str, Any]:
    """
    Esecuzione di n_simulations challenge prop a due fasi con CRN strettamente accoppiati per sfida (P-01).
    Validazione degli input estesa (S-06).
    """
    if not isinstance(n_simulations, int) or n_simulations < 1:
        raise ValueError(f"n_simulations deve essere intero >= 1, ricevuto: {n_simulations}")
    if not (math.isfinite(fase1_target) and fase1_target > 0.0):
        raise ValueError(f"fase1_target deve essere positivo e finito, ricevuto: {fase1_target}")
    if not (math.isfinite(fase2_target) and fase2_target > 0.0):
        raise ValueError(f"fase2_target deve essere positivo e finito, ricevuto: {fase2_target}")

    counts = {"pass": 0, "max_loss": 0, "daily_loss": 0, "absolute_ruin": 0, "timeout": 0}
    days_to_pass = []
    challenge_outcomes: List[str] = []

    for i in range(n_simulations):
        # Generatori accoppiati deterministici per sfida i
        base_i = (seed * 1_000_003 + i * 1_007) & 0xFFFFFFFF
        rng_out_p1 = random.Random(base_i)
        rng_mae_p1 = random.Random((base_i + 100_000) & 0xFFFFFFFF)
        rng_slip_p1 = random.Random((base_i + 200_000) & 0xFFFFFFFF)

        # Fase 1
        r1, d1, _ = simulate_phase_v3_3(
            rng_out_p1, rng_mae_p1, rng_slip_p1,
            scenario, risk_pct, trades_per_day, max_days_per_phase,
            fase1_target, max_daily_loss, max_overall_loss, min_days
        )
        if r1 != "pass":
            counts[r1] += 1
            challenge_outcomes.append(r1)
            continue

        # Fase 2: seed deterministico accoppiato per la Fase 2 della sfida i
        rng_out_p2 = random.Random((base_i + 500_000) & 0xFFFFFFFF)
        rng_mae_p2 = random.Random((base_i + 600_000) & 0xFFFFFFFF)
        rng_slip_p2 = random.Random((base_i + 700_000) & 0xFFFFFFFF)

        r2, d2, _ = simulate_phase_v3_3(
            rng_out_p2, rng_mae_p2, rng_slip_p2,
            scenario, risk_pct, trades_per_day, max_days_per_phase,
            fase2_target, max_daily_loss, max_overall_loss, min_days
        )
        if r2 != "pass":
            counts[r2] += 1
            challenge_outcomes.append(r2)
            continue

        counts["pass"] += 1
        days_to_pass.append(d1 + d2)
        challenge_outcomes.append("pass")

    results = {}
    for outcome, count in counts.items():
        ci_low, ci_high = wilson_confidence_interval(count, n_simulations, 0.95)
        results[outcome] = {
            "count": count,
            "rate": round(count / n_simulations, 4),
            "ci_95": (round(ci_low, 4), round(ci_high, 4))
        }
    results["median_days_pass"] = statistics.median(days_to_pass) if days_to_pass else None
    results["_challenge_outcomes"] = challenge_outcomes
    return results
