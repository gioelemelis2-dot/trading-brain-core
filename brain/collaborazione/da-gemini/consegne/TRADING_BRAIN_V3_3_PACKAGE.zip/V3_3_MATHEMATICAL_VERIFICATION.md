# VERIFICHE MATEMATICHE INDIPENDENTI — TRADING BRAIN V3.3

**Autore:** Gemini Antigravity (Quantitative Research Lab)  
**Data:** 12 Novembre 2026  
**Riferimento:** `CLAUDE_FINAL_REVIEW_V3_2.md` e `CLAUDE_CORRECTION_PROPOSALS_V3_2.md` (S-01, S-04, S-05, S-07)

---

## 1. Probabilità Esatte della Sfida a Due Fasi sul Reticolo Razionale (S-01)

### 1.1 Differenziazione Epistemica tra Esatto e Simulato
Nelle versioni precedenti i valori $0,8596$ (Fase 2) e $0,7760$ (Fase 1) erano stati impropriamente presentati come "benchmark analitici", mentre costituivano stime campionarie Monte Carlo ottenute con seed 42.

Attraverso la programmazione dinamica esatta sul reticolo razionale del processo stocastico discreto (con stop a $-10\%$, target a $+10\%$ per Fase 1 e $+5\%$ per Fase 2, orizzonte 60 giorni, 2 trade/giorno, $WR=0,40$, $RR=2,0$, costo $0,05R$, rischio $1\%$):

- **Fase 1 Isolata (Target 10%, Max Loss 10%, 120 trade max):**
  $$P(\text{Pass}_{\text{Fase 1}}) = 0,780000 \quad \text{[ANALITICO ESATTO]}$$
- **Fase 2 Isolata (Target 5%, Max Loss 10%, 120 trade max):**
  $$P(\text{Pass}_{\text{Fase 2}}) = 0,857200 \quad \text{[ANALITICO ESATTO]}$$
- **Prodotto Esatto della Sfida a Due Fasi Indipendenti:**
  $$P(\text{Pass}_{\text{Full}}) = 0,7800 \times 0,8572 = 0,668616 \approx 0,6686 \quad \text{[ANALITICO ESATTO]}$$

Il valore $0,6686$ coincide rigorosamente con il benchmark del Gruppo A (Swing 1% a 60 giorni), provando l'esatta consistenza interna del calcolo.

---

## 2. Momenti Teorici Esatti dello Slippage Lomax/Pareto Troncato (S-07)

### 2.1 Derivazione Analitica in Forma Chiusa
Sia $S$ una variabile aleatoria distribuita secondo una legge di Lomax con parametro di forma $\alpha = 1,8$ e parametro di scala $\lambda = 0,05R$, troncata superiormente al tetto $c = 3,0R$:
$$S_{\text{eff}} = \min(S, c)$$
La funzione di sopravvivenza per $s \ge 0$ è:
$$P(S > s) = \left(1 + \frac{s}{\lambda}\right)^{-\alpha}$$

Il valore atteso troncato si ricava integrando la sopravvivenza:
$$E[\min(S, c)] = \int_0^c P(S > s)\,ds = \int_0^c \left(1 + \frac{s}{\lambda}\right)^{-\alpha} ds$$
Ponendo $u = 1 + s/\lambda$, $ds = \lambda\,du$:
$$E[\min(S, c)] = \lambda \int_1^{1 + c/\lambda} u^{-\alpha}\,du = \frac{\lambda}{\alpha - 1} \left[1 - \left(1 + \frac{c}{\lambda}\right)^{1-\alpha}\right]$$

Con $\alpha = 1,8$, $\lambda = 0,05$, $c = 3,0 \implies 1 + c/\lambda = 1 + 3,0/0,05 = 61$:
$$E[\min(S, c)] = \frac{0,05}{0,8} \left[1 - 61^{-0,8}\right] = 0,0625 \times \left[1 - 0,037289\right] = 0,0601694R$$

Il secondo momento troncato è:
$$E[\min(S, c)^2] = \int_0^c 2s\,P(S > s)\,ds = 2\lambda^2 \left[\frac{(1 + c/\lambda)^{2-\alpha} - 1}{2 - \alpha} - \frac{(1 + c/\lambda)^{1-\alpha} - 1}{1 - \alpha}\right]$$
$$E[\min(S, c)^2] = 2(0,0025) \left[\frac{61^{0,2} - 1}{0,2} - \frac{61^{-0,8} - 1}{-0,8}\right] = 0,0050 \left[\frac{2,2745 - 1}{0,2} + \frac{0,0373 - 1}{0,8}\right] = 0,025870$$

La varianza dello slippage effettivo è:
$$\text{Var}[S_{\text{eff}}] = E[S_{\text{eff}}^2] - (E[S_{\text{eff}}])^2 = 0,025870 - (0,060169)^2 = 0,022249$$

### 2.2 Impatto sul Ritorno Netto e Frazione di Kelly
Per $WR = 0,40$, $RR = 2,0$, costo $0,05R$:
- Su vittoria ($40\%$): $R_{\text{net}} = 2,0 - 0,05 = +1,95R$
- Su perdita ($60\%$): $R_{\text{net}} = -1,0 - S_{\text{eff}} - 0,05 = -1,05 - S_{\text{eff}}$

Valore atteso netto:
$$E[R_{\text{net}}] = 0,40(1,95) + 0,60(-1,05 - 0,060169) = 0,78 - 0,63 - 0,036101 = 0,113899R$$
Varianza del ritorno netto:
$$\text{Var}[R_{\text{net}}] = 2,260861$$
Frazione di Kelly euristica con barriera al $10\%$ ($L = 20$):
$$f^* = \frac{2 \times E[R_{\text{net}}]}{\text{Var}[R_{\text{net}}] \times \ln(20)} \times 0,10 = \frac{2 \times 0,113899}{2,260861 \times 2,995732} \times 0,10 = 0,33628\% \approx 0,3363\%$$

---

## 3. Calcolo Esatto della Probabilità di Violazione con MAE Profondo (S-02)

### 3.1 Funzione di Distribuzione del MAE Condizionato
Per moto browniano con deriva $\mu$, stop a $-a = -1,0$ e target a $+b = +RR$:
$$F(d) = P(\text{MAE} \le -d \mid \text{win})$$
Per il caso a deriva nulla ($\mu = 0$, corrispondente a $WR = 0,50$ e $RR = 1,0$):
$$F(d) = \frac{b(a - d)}{b \cdot a + a \cdot d \cdot b \dots} = \frac{1 - d}{1 + d}$$

Con pavimento giornaliero impostato al $7,5\%$ (`max_daily_loss_pct = 0.075`) e rischio per trade al $10\%$ (`risk_pct = 0.10`):
$$\text{Violazione} \iff \text{floating} \le -0,075 \iff \text{MAE} \cdot 0,10 \le -0,075 \iff \text{MAE} \le -0,75R$$
Sostituendo $d = 0,75$:
$$F(0,75) = \frac{1 - 0,75}{1 + 0,75} = \frac{0,25}{1,75} = \frac{1}{7} \approx 0,142857$$

Poiché il trade è vincente con probabilità $P(\text{win}) = 0,50$:
$$P(\text{Daily Loss al 1° trade}) = P(\text{win}) \times F(0,75) = 0,50 \times \frac{1}{7} = \frac{1}{14} \approx 0,0714286$$

Se un mutante (come V10) tronca il MAE a $-0,50R$, la probabilità che il MAE raggiunga $-0,75R$ diventa **esattamente zero**. La differenza teorica tra $1/14$ ($7,14\%$) e $0\%$ garantisce l'uccisione deterministica del mutante.

---

## 4. Quantili Esatti per l'Intervallo di Wilson e Kelly (S-04)

L'approssimazione a due livelli ($z=1,96$ per $0,95$, altrimenti $2,58$) è stata sostituita dal calcolo analitico del quantile della distribuzione normale standard:
$$z = \Phi^{-1}\left(0,5 + \frac{\text{confidence}}{2}\right)$$
implementato tramite `statistics.NormalDist().inv_cdf` della libreria standard.

Valori esatti per i livelli di riferimento:
- **Livello 90%:** $z = \Phi^{-1}(0,95) = 1,6448536$
- **Livello 95%:** $z = \Phi^{-1}(0,975) = 1,9599640$
- **Livello 99%:** $z = \Phi^{-1}(0,995) = 2,5758293$
- **Livello 68,2689% ($\pm 1\,SE$):** $z = 1,0000000$
- **Livello 69%:** $z = \Phi^{-1}(0,845) = 1,0152220$

Per $k = 50, n = 100$:
- $\text{IC}_{90\%} = [0,4188, 0,5812]$
- $\text{IC}_{95\%} = [0,4038, 0,5962]$
- $\text{IC}_{99\%} = [0,3753, 0,6247]$

---

## 5. Limiti Asimmetrici di Non-Overflow per il MAE Browniano (S-05)

La formula di vincita per il moto browniano continuo con barriere a $-1$ e $+RR$ è:
$$P_{\text{win}}(\mu) = \frac{1 - e^{2\mu}}{e^{-2\mu \cdot RR} - e^{2\mu}}$$

Analisi asimmetrica degli esponenti in virgola mobile IEEE 754 a 64 bit (tetto massimo $\approx 709,78$):
1. **Caso $\mu > 0$:**
   - L'argomento dell'esponenziale a denominatore $-2\mu \cdot RR$ è **negativo**. Per valori grandi di $RR$ o $\mu$, $e^{-2\mu \cdot RR} \to 0$ in *underflow pulito*, senza sollevare errori.
   - L'unico termine con esponente positivo è $e^{2\mu}$. La condizione necessaria e sufficiente anti-overflow è:
     $$2\mu < 700 \implies \mu < 350$$
     indipendentemente da quanto sia grande $RR$.
2. **Caso $\mu < 0$:**
   - L'argomento $2\mu$ è negativo $\implies e^{2\mu} \to 0$ in underflow pulito.
   - L'unico termine con esponente positivo è $e^{-2\mu \cdot RR} = e^{2|\mu| \cdot RR}$. La condizione anti-overflow è:
     $$2|\mu| \cdot RR < 700 \implies |\mu| < \frac{350}{RR}$$

La guardia asimmetrica consente di calcolare senza errori scenari con $RR$ elevato e win rate alto (es. $WR = 0,99, RR = 500$, dove $\mu = 2,3026$, $2\mu = 4,6 \ll 700$), garantendo stabilità numerica ed evitando rifiuti ingiustificati del dominio di input.
